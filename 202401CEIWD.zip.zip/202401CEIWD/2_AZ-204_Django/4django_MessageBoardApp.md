# Create a new App that can Post from HTML UI to the Database

1. create a new directory for our code on the Desktop called `4django`

2. install Django in a new virtual environment

3. create a new project called `mb_project`

4. create a new app call `posts`

5. update settings.py

mkdir 4django
cd 4django
pipenv install django
django-admin startproject mb_project .
python manage.py startapp posts

```python
# mb_project/settings.py
INSTALLED_APPS = [
    "posts.apps.PostsConfig",
```

6. Generate the database

migrate command to create an initial database based on Django’s default settings

> python manage.py migrate

```bash
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, sessions
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
  Applying admin.0002_logentry_remove_auto_add... OK
  Applying admin.0003_logentry_add_action_flag_choices... OK
  Applying contenttypes.0002_remove_content_type_name... OK
  Applying auth.0002_alter_permission_name_max_length... OK
  Applying auth.0003_alter_user_email_max_length... OK
  Applying auth.0004_alter_user_username_opts... OK
  Applying auth.0005_alter_user_last_login_null... OK
  Applying auth.0006_require_contenttypes_0002... OK
  Applying auth.0007_alter_validators_add_error_messages... OK
  Applying auth.0008_alter_user_username_max_length... OK
  Applying auth.0009_alter_user_last_name_max_length... OK
  Applying auth.0010_alter_group_name_max_length... OK
  Applying auth.0011_update_proxy_permissions... OK
  Applying auth.0012_alter_user_first_name_max_length... OK
  Applying sessions.0001_initial... OK
```

Notice the `db.sqlite3` database created by the migrate command

> ls -lha

`db.sqlite3` file (database) is created the first time we run either the **migrate** or **runserver** commands. Using runserver configures a database using Djang's default settings, however migrate will sync the database with the current state of any database models contained in the project and listed in `INSTALLED_APPS`. In other words, to make sure the database reflects the current state of your project you'll need to run migrate (and also `makemigrations`) each time you update a model.

> python manage.py runserver

--- 

# To view db.sqlite3:
- Download  DBeaver to view the sqllite Database: https://dbeaver.io/download/

- Or use DB Shell to query the database



### DBeaver: import db.sqlite3 Database

1.  Copy Path to db.sqlite3 file in VSCode > Right-Click on `db.sqlite3`

2. Open DBeaver:
- Create New Database Connection (top-left)
- Select SQLLITE
- Test Connection
- Rename the Database to include your Source Folder name because later on we will add more databases

> ls -lrtha
28K Jan 31 14:58 db.sqlite3

In the Database expand the Tables. Right-Click on a Table and select "View Table" to open up the Table Definitions and by default it will open "properties" tab. Select "data" tab of the Table Definitions. You can click on the "Refresh" button on the bottom left.


# Django Admin:

Django comes built- with a robust admin interface for interacting with our database. Only few web-frameworks have this feature. 

To use the Django admin, we first need to create a ***superuser*** who can login. In CLI:

> python manage.py createsuperuser  
> uUsername (leave blank to use 'aj'): admin  
> Email address: email@gmail.com  
> Password:   
> Password (again):   
> Bypass password validation and create user anyway? [y/N]: y  

Let's test out our admin account:
> python manage.py runserver  

Login to the admin page:
http://127.0.0.1:8000/admin/

In DBeaver go to `Tables` > `auth_user` > Click Refresh. This will show the admin user. Notice `password` column hash/salt.


# Create a Database Model called `Post`:
https://docs.djangoproject.com/en/4.2/ref/models/fields/

models.py where we will store and display posts from our users. Django will turn this model into a database table. In a production webapp there will be many complex, interconnected database models but in our simple message board app we will only use one.

Each app-level directory will have it's models.py file created when we run `python manage.py startapp appname` and each of these app-level folders will have their corresponding tables in the database.

posts/models.py
```python
# posts/models.py
from django.db import models

# to store the textual content of a message in a post

class Post(models.Model):
    text = models.TextField() 
    # this will be our column in the table Post
```

## Activate our new Model:

Whenever we create or modify and existing model we'll need to update Django in a two-step process: (make sure the server is stopped)

1. We create a migration file with the `makemigrations` command which generates the SQL Commands for preinstalled apps in our INSTALLED_APPS setting. It will generate this migrations file: 4django/posts/migrations/0001_initial.py Migration will not execute those sql commands on our database file, rather they are a reference of all new changes to our models. This approach means that we have a record of the changes to our models over time.

2. We build the actual database with `migrate` command which does execute the instructions from our migrations file generated in step 1

Stop the running server
> control+C

> python manage.py makemigrations posts
created: 4django/posts/migrations/0001_initial.py

> python manage.py migrate posts
fired sql commands in database: posts.0001_initia

```bash
$ python manage.py makemigrations posts
Migrations for 'posts':
  posts/migrations/0001_initial.py
    - Create model Post


$ python manage.py migrate posts
Operations to perform:
  Apply all migrations: posts
Running migrations:
  Applying posts.0001_initial... OK
```
Model Fields: https://docs.djangoproject.com/en/5.0/ref/models/fields/

In the DBeaver `db.sqlite3-4django` Database, right-click and refresh the tables. You will see our new model has created a table called `posts_post` and notice the column name `text`. The `id` column in automatically created to provide a sequence number to each row.

Check in Admin App that Posts Model shows up.

# Connect our new Model with our Admin App/UI:

Our Posts Model is not showing up in the Admin App. We need to explicitly tell Django what to display in posts/admin.py

Django now knows that it should display our posts app and its database model Post on the admin page.

```python
# posts/admin.py
from django.contrib import admin

# Register your models here.
from .models import Post

admin.site.register(Post)
```

### Create our First Post from Admin UI:

In the Admin Page add a new post via the UI.

You can change/modify data in the database via Admin UI. You will see:
> The post “Post object (1)” was added successfully.

If you look closely our new entry is called “Post object”. You can check in DBeaver by clicking refresh button on the bottom center to display contents of our first post.

### Instead of storing an object we will store the string:

```python
# posts/models.py
from django.db import models

# to store the textual content of a message in a post

class Post(models.Model):
    text = models.TextField() 
    # this will be our column in the table Post

    def __str__(self):
        return self.text[:50]
    # this will display 50 character of the text field in the Admin UI, you can store more characters in the database but in the Admin UI only the first 50 will show up.
```

Add more Posts from the Admin UI and notice in the Database the `ids` are created automatically.

# Display Database Content on our Home Page: Templates > Views > URLs

Add our Model to our posts/views.py to extract data from the database.

Earlier we used TemplateView to display a template file on our homepage. Now we want to list the contens of our database model `Post` and this is very common task, so Django has a generic class-based ListView

Class Based Views: https://docs.djangoproject.com/en/5.0/topics/class-based-views/

```python
# posts/views.py
from django.views.generic import ListView
from .models import Post
# Internally in Django ListView returns an object called object_list that we want to display in our template.

# Create your views here.
class HomePageView(ListView):
    model = Post # extract data from our model
    template_name = 'home.html' # associate a template to be used with this view
```
Our view.py file is now complete, so next we need to make our template and configure our URLs.

> mkdir templates
> touch templates/home.html

Now we wire-up our new `templates` folder located in our source folder to contain all of our furture templates. We do that in our mb_project/settings.py file. 

```python
# mb_project/settings.py
...
# line 13
from pathlib import Path, os
...
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [os.path.join(BASE_DIR, 'templates')] ,# Centralize Templates in the Source Folder
```

In our templates file `home.html` we will use Django Templating Languge's f`or loop` to list all the `objects` in `object_list` with `ul` and `li` tags.

`object_list` is the default variable name that `ListView` returns which we will later on customize.

templates/home.html : 
```html
<!-- templates/home.html -->
<h1>Message board Homepage:</h1>

<ul>
    {% for post in all_posts_list %}
        <li>{{ post }}</li>
    {% endfor %}
</ul>
```

`object_list` is a generic name and as a Django best-practice we should customize it to makes it easier for developers and especially designers to know what is contained in the template.

Create a specific Object_List in posts/views.py: 
```python
# posts/views.py
from django.views.generic import ListView
from .models import Post
# Internally in Django ListView returns an object called object_list 
# that we want to display in our template.

# Create your views here.
class HomePageView(ListView):
    model = Post # extract data from our model
    template_name = 'home.html' # associate a template to be used with this view
    context_object_name = 'all_posts_list' # template's object_list a specific name
```

Make sure to update the templates/home.html
> {% for post in all_posts_list %}

We need to wire up our view and template in urls but there is no file there so let's create it.

> touch posts/urls.py

```python
from django.urls import path

from .views import HomePageView

urlpatterns = [
    path('',HomePageView.as_view(), name='home')
]
```

Next we wire up this app-level urls.py with project-level urls.py:
```python
# mb_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', include('posts.urls')),
]
```

Restart the server:
> python manage.py runserver 

And navigate to our homepage home.html at http://127.0.0.1:8000/

- add new Posts in Admin UI
- Notice the new rows in DBeaver
- Notice the new list item in our homepage

# Tests: add UnitTests

Before we were only testing static pages so we could use `SimpleTestCase`. But now that our `webapp` works with a `database`, we need to use `TestCase` which will let us create a `test` database we can check against.

We don’t need to run tests on our actual database but instead can make a separate test database, fill it with sample data, and then test against it.

## Test on our Model:

- add a sample post to the text database field
- then check whether it stored correctly in the database

It's important that all our test methods starts with `test_` so Django knows to test them.

```python
# posts/tests.py
from django.test import TestCase
# TestCase lets us create a sample database
from .models import Post

# Create your tests here.
class PostModelTest(TestCase):
    def setUp(self):
        Post.objects.create(text='object was created')
    # new class PostModelTest and add a method setUp to create a 
    # new database that has just one entry: a post with a text field 
    # containing the string 'object was created'
    
    def test_text_content(self):
        post = Post.objects.get(id=1)
        expected_object_name = f'{post.text}'
        self.assertEqual(expected_object_name, 'expected object was post.text')
        # Here we run our firt test called "test_text_content" to check that the
        # database field actually contains a "test". We created a variable called
        # "post" that respresents the first id on our Post Model. If we created
        # another entry for our test Django will automatically give an id = 2
        # f strings let us put variables directly in our strings with the {} brackets.
        # Here we are setting expected_object_name to be the string of 
        # the value in post.text (which is "object was created").

# To run our test:
# python manage.py test
```
> python manage.py test

Most UnitTests we write are going to be quite repetitive, so you'll get a hang of it.

## Test our Homepage called `home` at path ``:

- Test that homepage `exits` (throws HTTP Status Code `200`)
- Test that it uses the `HomePageView` view
- Test that it uses the `home.html` template

We'll import for reverse and a brand new class HomePageViewTest for our test.

```python
# posts/tests.py
from django.test import TestCase
# TestCase lets us create a sample database
from django.urls import reverse # let's us test our view
from .models import Post
...
...
...
# Test our Homepage: checking the pattern Template > View > URLs
class HomePageViewTest(TestCase):
    # setUp methods are not actually test but they enable us to run the 
    # subsequent tests
    def setUp(self):
        Post.objects.create(text="creating another object for testing")
    
    # Testing whether our view exists by URL
    def test_view_url_exists_at_proper_location(self):
        resp = self.client.get('/')
        self.assertEqual(resp.status_code, 200)
    
    # Testing whether our view exists by name
    def test_view_url_by_name(self):
        resp = self.client.get(reverse('home'))
        self.assertEqual(resp.status_code, 200)
    
    # Testing whether our template was applied to create the view
    def test_view_uses_correct_template(self):
        resp = self.client.get(reverse('home'))
        self.assertEqual(resp.status_code, 200)
        self.assertTemplateUsed(resp, 'home.html')
```

> python manage.py test

### How many tests show up in the test-run count? Share that number in private chat.
We'll wait 10 min. 

Responded: David, Gayatri, Robert, Brittany, Miguel, James, 

Driving: Corey, John Barber, Mercy

? Taiwo, John Holder

```bash
$ python manage.py test

Found 4 test(s).
Creating test database for alias 'default'...
System check identified no issues (0 silenced).
...F
======================================================================
FAIL: test_text_content (posts.tests.PostModelTest)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/aj/4django/posts/tests.py", line 21, in test_text_content
    self.assertEqual(expected_object_name, 'expected object was post.text')
AssertionError: 'object was created' != 'expected object was post.text'
- object was created
+ expected object was post.text


----------------------------------------------------------------------
Ran 4 tests in 0.022s

FAILED (failures=1)
Destroying test database for alias 'default'...
```

Change the text of `test_text_content` function to match the text passed in the `setUp` function so that the `left-hand-side` (expected_object_name) and `right-hand-side` ('sample text: object was created') of assertEqual matches:
> self.assertEqual(expected_object_name, 'sample text: object was created')

Re-run Tests:
> python manage.py test

```bash
$ python manage.py test

Found 4 test(s).
Creating test database for alias 'default'...
System check identified no issues (0 silenced).
....
----------------------------------------------------------------------
Ran 4 tests in 0.021s

OK
Destroying test database for alias 'default'...
```

Success!