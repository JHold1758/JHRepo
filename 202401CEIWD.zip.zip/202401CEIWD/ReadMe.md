Please do not share this repo outside of Divergence Student Cohort you are in.

## Tooling Needed:
1. Python
    -  Python 3 Interpreter
    
2. VS Code and VS Code Extensions:
    - Azure CLI
    - Azure Core


9. Optional:
    - Postman App: Test APIs

# January 2024:
|	Mon	|	Tue	|	Wed	|	Thu	|	Fri	|	Sat	|	Sun	||
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |:---: |
|	1	|	2	|	3	|	4	|	5	|	6	|	7	||
|	8	|	9	|	10	|	11	|	12	|	13	|	14	||
|	15	|	16	|	17	|	18	|	19	|	20	|	21	||
|	22	|	23	|	24	|	25	|	26	|	27	|	28	|Custom Capstone Resource Deployment| 
|	29	|	30	|	31	|		|		|		|		|AZ-204 1|

<br>

# February 2024:
|	Mon	|	Tue	|	Wed	|	Thu	|	Fri	|	Sat	|	Sun	||
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |:---:|
|		|		|		|	1	|	2	|	3	|	4	|AZ-204 1|
|	5	|	6	|	7	|	8	|	9	|	10	|	11	|AZ-204 2 (toughest)|
|	12	|	13	|	14	|	15	|	16	|	17	|	18	|AZ-400|
|	19	|	20	|	21	|	22	|	23	|	24	|	25	|DevOps Scenarios|
|	26	|	27	|	28	|		|		|		|		|*Ansible|
<br>

# March 2024:
|	Mon	|	Tue	|	Wed	|	Thu	|	Fri	|	Sat	|	Sun	||
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |:---:|
|		|		|		|		|	1	|	2	|	3	|*Ansible|
|	4	|	5	|	6	|	7	|	8	|	9	|	10	|*Kubernetes|
|	11	|	12	|	13	|	14	|	15	|	16	|	17	|Final Capstone|
|	18	|	19	|	20	|	21	|	22	|	23	|	24	||
|	25	|	26	|	27	|	28	|	29	|	30	|	31	||

* https://mdcal.io/