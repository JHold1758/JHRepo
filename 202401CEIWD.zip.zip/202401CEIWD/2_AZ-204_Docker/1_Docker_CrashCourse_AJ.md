# Docker Introduction by Ankit Jariwala (AZ-204)

# Install Docker Desktop: 
- Windows: https://docs.docker.com/desktop/install/windows-install/

- Mac: https://docs.docker.com/desktop/install/mac-install/
  
Docker Tutorials: 
- https://www.docker.com/play-with-docker/ have Docker for Desktop Installed
    1) Start Docker for Desktop Application on your Windows/Mac
    2) In CLI Run: docker run -dp 80:80 docker/getting-started:pwd
    3) In Browser open: http://localhost/ or http://localhost/tutorial/

- Docker Cheatsheets on GitHub
- For more Docker examples, visit: https://docs.docker.com/get-started/

DockerHub: Share images, automate workflows, and more with a free Docker ID
- Create a free DockerHub Account: https://hub.docker.com

VSCode:
- VSCode Docker Extension by Microsoft: `ms-azuretools.vscode-docker`
- Integrated Terminal auto complete does not work for Docker Commands

Docker API:
- https://docs.docker.com/engine/reference/commandline/exec/


# Docker Desktop

Docker Desktop is a native application that delivers all of the Docker tools to your Mac or Windows Computer.

After installing, launch your new application "Docker for Desktop" 

If Docker for Desktop is not running then any Docker commands will give you an error. 

```bash
docker ps
Cannot connect to the Docker daemon at unix:///var/run/docker.sock. Is the docker daemon running?
```
Make sure Docker for Desktop is running before you procced further.

Daemon: is a process (with PID) that runs in the background of the operating system. Some examples are httpserver, dockerDaemon, 

# Play with Docker: Docker Main Tutorial
Play with Docker is an interactive playground that allows you to run Docker commands on a linux terminal, no downloads required.

### play-with-docker using only the browser
1. Log into https://labs.play-with-docker.com/ to access your PWD terminal
2. Type the following command in your PWD terminal: docker run -dp 80:80 docker/getting-started:pwd
3. Wait for it to start the container and click the port 80 badge
4. Have fun!

### Play with Docker using Docker for Desktop:
1. Open Docker Desktop. (Download here if you don’t have it).
2. Type the following command in your terminal: docker run -dp 80:80 docker/getting-started
3. Open your browser to: http://localhost/
4. Have fun!

---
+-----------------------------+-------+-----------+
|             Domain          | Meta  | Concrete  |
+-----------------------------+-------+-----------+
| Docker                      | Image | Container |
| Object oriented programming | Class | Object    |
+-----------------------------+-------+-----------+

| Domain | Meta | Concrete |
|--------|------|----------|
|Docker  | Image | Container |
| Object Oriented Programming | Class | Object |

# DockerHub: a Container Image Registry

Create a free DockerHub Account, like GitHub is to the Source Folders DockerHub is to Container-Images.

# Docker Commands:
<!-- Docker Version -->
> docker --version  
> Docker version 20.10.23, build 7155243

> docker-compose --version  
> Docker Compose version v2.15.1  

<!-- Currently Running Container -->
> docker ps

<!-- Stopped Containers as well -->
> docker ps -a

# Docker Images:

All the Images in your system
> docker images

> docker rmi image_name

When docker pull cannot find image locally then it will pull it automatically from DockerHub.

Docker Images are a lightweight, standalone, executable package of software that includes everything needed to run an application: code, runtime, system tools, system libraries and settings.

Images are the blueprint of a container.

Images of different software can be pulled from DockerHub. And like GitHub, DockerHub is called a Container Registry which stores public images (public repo in github)  and you can create an account for private images for your company.

```bash
$ docker run --name busybox1 -itd busybox /bin/sh

Unable to find image 'busybox:latest' locally
latest: Pulling from library/busybox
9ad63333ebc9: Pull complete 
Digest: sha256:6d9ac9237a84afe1516540f40a0fafdc86859b2141954b4d643af7066d598b74
Status: Downloaded newer image for busybox:latest
226b96394ac3aa2d3794d953862afe26463209634629b81754dfa1ccafda95f6
```
> docker exec -it busybox1 /bin/sh   
> uname -
> hostname  
> exit   

For more information: https://hub.docker.com/_/busybox

### Pull an image from DockerHub:
```bash
# visit the DockerHub page for alpine
# https://hub.docker.com/_/alpine
$ docker pull alpine

$ docker pull busybox

# https://hub.docker.com/u/schoolofcompsci
$ docker pull schoolofcompsci/hello-world-rest-api:0.0.1.RELEASE
.0.1.RELEASE: Pulling from schoolofcompsci/hello-world-rest-api
Digest: sha256:00469c343814aabe56ad1034427f546d43bafaaa11208a1eb0720993743f72be
Status: Image is up to date for schoolofcompsci/hello-world-rest-api:0.0.1.RELEASE
docker.io/schoolofcompsci/hello-world-rest-api:0.0.1.RELEASE
```
--- 
# What is Alpine Linux?

https://hub.docker.com/_/alpine

Alpine Linux, like BusyBox, is a LIGHT-WEIGHT but a Secure & Production-Ready `Linux distribution` built around `musl libc` and `BusyBox`. ***The image is only `5 MB in size` and has access to a package repository that is much more complete than other BusyBox based images.*** This makes Alpine Linux a great image base for utilities and even `production applications`. 

> 5. APP  

> 4. Binaries (bin) + Libraries (libs)  

> 3. Docker Daemon (Container Engine)  

> 2. Host Operating System (Linux/Windows)  

> 1. Hardware  

--- 

# Containers:
A container is a runtime instance of a docker image. A container will always run the same, regardless of the infrastructure. Containers isolate software from its environment and ensure that it works uniformly despite differences for instance between development and staging.

### Create a Container out of an Image: `run`
> docker run -d --name MyAlpineC1 alpine tail -f /dev/null  

Another way to create a container and the Daemon will give it's own name:
> docker container run -itd alpine /bin/sh

### Run a Container:
docker container run `-mode` `--name containername` `imagename`

Docker run command will look for the image locally and if it cannot find it then it will pull it from DockerHub based on the image name you have provided.
```bash
docker container run -itd --name a1 alpine
Unable to find image 'alpine:latest' locally
latest: Pulling from library/alpine
c926b61bad3b: Pull complete 
Digest: sha256:34871e7290500828b39e22294660bee86d966bc0017544e848dd9a255cdf59e0
Status: Downloaded newer image for alpine:latest
33063c569f66c963c44d69f0c0377761c34efa4bc177a42b17d878a2e220454e
```

### Enter inside a Running Conatiner:

### Connect to a Container Running in Daemon mode: `exec`
> docker exec -it d3e10767e9e2 bin/sh

You can get container id from `docker ps` command  

- `-it` here stands for interactive terminal

- the shell or cli of the container is located in `bin/sh`

To exit out of the interactive mode:
> exit 

You can also use container name in the exec command:
> docker exec -it determined_buck bin/sh

Some great Linux Commands you can execute:
> uname -a  
> hostname  
> free  
> date   
> uptime  
> ping google.com  
> cd ~  
> cd ..  
> curl https://www.exmaple.com/ 
> wget https://www.exmaple.com/downloads/version1   
> sudo  {any command as administrator}

You have to keep in mind that different Linux Distros have different commands for updating packages, for exmaple: apt, yum, etc

In Linux you can chain two commands by `&&`

Let's enter inside another container:
> docker exec -it a1 /bin/sh

Inside Alpine:
```bash
$ cat /etc/os-release 

NAME="Alpine Linux"
ID=alpine
VERSION_ID=3.18.5
PRETTY_NAME="Alpine Linux v3.18"
HOME_URL="https://alpinelinux.org/"
BUG_REPORT_URL="https://gitlab.alpinelinux.org/alpine/aports/-/issues"

$ exit
```
---

# Other Container Commands:
### Properties of a container:<br>
> docker inspect -f "{{ .Config.Env }}" c3f279d17e0a

### Inspect a running container:
> docker inspect a1

### Fetch and follow the logs of a running container:
> docker logs -f a1

### View Resource usage by the containers:
> docker container stats
```bash
CONTAINER ID   NAME      CPU %     MEM USAGE / LIMIT   MEM %     NET I/O         BLOCK I/O        PIDS
33063c569f66   a1        0.00%     792KiB / 7.671GiB   0.01%     1.99kB / 868B   0B / 20.5kB      2
c2b7b8f12aa5   bb1       0.00%     740KiB / 7.671GiB   0.01%     2.33kB / 574B   586kB / 65.5kB   1
```
---

# Docker Daemon and Engine:
### Information about your Docker Engine:
> docker info

### To start docker daemon manually in linux:
> docker -d
Since we are running docker for desktop you can click on this application and start the daemon; terminate the application and it will kill the daemon.

---

# Stop vs Kill Container:
### Stop a Container:
> docker stop `container_id_1` 
> docker stop `container_id_1` `container_id_2` `container_id_3`

### Stop all Containers: using the query and nesting the query
> docker stop $(docker ps -q) 

### Send Kill Signal to all Containers<br>
> docker kill $(docker ps -q)  

### Remove all Docker Containers (which also stops them):<br>
> docker rm $(docker ps -a -q)

---

# Deleting Images:

### Remove all Docker Images:<br>
> docker rmi $(docker images -q)  

### To remove all unused images:
> docker image prune

---

# Azure Architecture Center: Sidecard Pattern
https://learn.microsoft.com/en-us/azure/architecture/patterns/sidecar

---
# Create an Image out of your Source Code Folder:

So you can later run a container out of it. When designing the image make sure to put in everything that is needed for the container to run. An Image and subsequently its Container will be like a cocoon for your application.

# Dockerfile

To package the code in 5django_docker folder, create a new file at the Source Code Level Directory (or at BASE_DIR):
> touch Dockerfile

Make sure the requirements.txt file has all the pip packages your Django Application needs are listed.

Edit the `Dockerfile` with:
```yaml
FROM python:3.7-alpine

# sets and configures the working directory within the container to /usr/src/app.
WORKDIR /usr/src/app

# set environment variables
# Prevents Python from copying pyc files to the container
ENV PYTHONDONTWRITEBYTECODE 1

# It catches the output to stdout and cleans and flushes out instantly
# It generates the logs in real-time, and monitors with the Django.
ENV PYTHONUNBUFFERED 1

# installs and upgrades the pip version within the container 
RUN pip install --upgrade pip

# copies and moves all the requirements.txt files within the container’s work directory
COPY requirements.txt /usr/src/app

# Installs the requirements 
# this  file has "django" mentioned, which will be installed in this step
RUN pip install -r requirements.txt

# Copies and moves all the application source code to the working directory in the container.
COPY . /usr/src/app
```
We will now use the instructions in Dockerfile to build an image from which we will spinup containers.

To build this dockerfile, run following in the terminal:
> docker build .

```bash
docker build .   
[+] Building 12.0s (9/9) FINISHED                                                                     docker:desktop-linux
 => [internal] load build definition from Dockerfile                                          0.0s
 => => transferring dockerfile: 398B                                                          0.0s
 => [internal] load .dockerignore                                                             0.0s
 => => transferring context: 2B                                                               0.0s
 => [internal] load metadata for docker.io/library/python:3.7                                 0.6s
 => [1/4] FROM docker.io/library/python:3.7@sha256:eedf63967cdb57d8214db38ce21f105003ed4e4d0358f02bedc057341bcf92a0                    0.0s
 => [internal] load build context                                                             0.0s
 => => transferring context: 2.26kB                                                           0.0s
 => CACHED [2/4] WORKDIR /code                                                                0.0s
 => [3/4] RUN pip install django                                                              10.6s
 => [4/4] COPY . /code/                                                                       0.0s 
 => exporting to image                                                                        0.7s 
 => => exporting layers                                                                       0.7s 
 => => writing image sha256:74f28097a92e200eb1eb5b9ee9a0ccdaeea0a1805cd8c006608abaa1e916b78e  0.0s 

What's Next?
  View a summary of image vulnerabilities and recommendations → docker scout quickview
```

> touch docker-compose.yml

Now build docker-compose.yml to build container images and run containers based on it.

Mind the "tabs" in the yaml file, or you can also use two spaces instead of a tab. 

```bash
version: '3.7' #Version of Docker-Compose

services: # Specify Containers we want to have running within our Docker host
# it’s possible to have multiple services running, but for now we just have one for web.
  web:
    # how to build the container by saying "Look in the current directory" with  '.' for the Dockerfile
    build: . 
    
    # Then within the container run the command to start up the local server.
    command: python /usr/src/app/manage.py runserver 127.0.0.0:8000

    # The volumes 33 mount automatically syncs the Docker filesystem with our local computer’s filesystem. 
    # This means that we don’t have to rebuild the image each time we change a single file!
    volumes:
      - .:/usr/src/app
    ports:
      - 8000:8000
```