Azure Lab RDP: 
Username: divergence
H$olidays2022

Mac Users Download: Microsoft's RDP
