Git Commands
============

_This list features the most important and commonly used Git commands for a easy reference_   

`Git` is the ***free and open source distributed version control system*** that's responsible for everything GitHub related **that happens locally on your computer**. 

Git Command List: https://git-scm.com/docs  

Git aliases are stored in `.bash_profile`, here is a sample: https://github.com/joshnh/bash_profile/blob/master/.bash_profile

Git Pro Book: https://git-scm.com/book/en/v2   

Git Pro Book PDF Download: https://github.com/progit/progit2/releases/download/2.1.416/progit.pdf  
---

## Installation & GUIS
With platform speciﬁc installers for Git, GitHub also provides the ease of staying up-to-date with the latest releases of the command line tool while providing a graphical user interface for day-to-day interaction, review, and repository synchronization

| Machine OS | Description |
| ------- | ----------- |
| GitHub for Windows| https://windows.github.com|
| GitHub for Mac| https://mac.github.com|
|For Linux and Solaris platforms | the latest release is available on the oﬃcial Git web site|
|Git for All Platforms| http://git-scm.com |

&nbsp; 

## Setup

Conﬁguring user information used across all local repositories

| Command | Description |
| ------- | ----------- |
| `git config --global user.name “[firstname lastname]”` |set a name that is identiﬁable for credit when review version history |
| `git config --global user.email “[valid-email]”` | set an email address that will be associated with each history marker |
| `git config --global color.ui auto` | set automatic command line coloring for Git for easy reviewing |

&nbsp; 

## Starting / Getting / Creating Projects
Conﬁguring user information, initializing and cloning repositories

| Command | Description |
| ------- | ----------- |
| `git init` | Initialize an existing directory as a Git repository. Initialize a local Git repository |
| `git clone ssh://git@github.com/[username]/[repository-name].git` | Create a local copy of a remote repository. Retrieve an entire repository from a hosted location via URL. Clone will `create` a folder at the location from where you are running the clone command, and initiates `init` it in your local environment, and also adds the remote folder to your `origin` command. |

&nbsp; 

### Basic Snapshotting
Working with snapshots and the Git staging area
| Command | Description |
| ------- | ----------- |
| `git status` | Check status, show modiﬁed ﬁles in working directory, staged for your next commit. |
| `git add [file-name.txt]` | Add a file to the staging area. Add a ﬁle as it looks now to your next commit (stage).|
| `git add -A` | Add all new and changed files to the staging area |
| `git commit -m "[commit message]"` | Commit changes. Commit your staged content as a new commit snapshot |
| `git rm -r [file-name.txt]` | Remove a file (or folder) |
| `git reset [file]` | Unstage a ﬁle while retaining the changes in working directory |
| `git diff` | diﬀ of what is changed but not staged | 
| `git diff --staged` | diﬀ of what is staged but not yet committed |


&nbsp; 

## Branching & Merging
Isolating work in branches, changing context, and integrating changes
| Command | Description |
| ------- | ----------- |
| `git branch` | List branches (the asterisk denotes the current branch) |
| `git branch -a` | List all branches (local and remote) |
| `git branch [branch name]` | Create a new branch |
| `git branch -d [branch name]` | Delete a branch |
| `git push origin --delete [branch name]` | Delete a remote branch |
| `git checkout -b [branch name]` | Create a new branch and switch to it |
| `git checkout -b [branch name] origin/[branch name]` | Clone a remote branch and switch to it |
| `git branch -m [old branch name] [new branch name]` | Rename a local branch |
| `git checkout [branch name]` | Switch to a branch |
| `git checkout -` | Switch to the branch last checked out |
| `git checkout -- [file-name.txt]` | Discard changes to a file |
| `git merge [branch name]` | Merge a branch into the active branch |
| `git merge [source branch] [target branch]` | Merge a branch into a target branch |
| `git stash` | Stash changes in a dirty working directory |
| `git stash clear` | Remove all stashed entries |

&nbsp; 

## Share & Update Projects
Retrieving updates from another repository and updating local repos
| Command | Description |
| ------- | ----------- |
| `git push origin [branch name]` | Push a branch to your remote repository |
| `git push -u origin [branch name]` | Push changes to remote repository (and remember the branch) |
| `git push` | Push changes to remote repository (remembered branch) |
| `git push origin --delete [branch name]` | Delete a remote branch |
| `git pull` | Update local repository to the newest commi. Fetch and merge any commits from the tracking remote brancht |
| `git pull origin` [branch name] | Pull changes from remote repository |
| `git remote add origin` ssh://git@github.com/[username]/[repository-name].git | Add a remote repository |
| `git remote add` [alias] [url] |add a git URL as an alias| 
| `git remote set-url origin` ssh://git@github.com/[username]/[repository-name].git | Set a repository's origin branch to SSH |
| `git fetch` [alias] | fetch down all the branches from that Git remote |
| `git merge` [alias]/[branch] | merge a remote branch into your current branch to bring it up to date|
| `git push` [alias] [branch] |Transmit local branch commits to the remote repository branch |

&nbsp; 

## Inspect & Compare

Examining logs, diﬀs and object information

| Command | Description |
| ------- | ----------- |
| `git log` | View changes |
| `git log --summary` | View changes (detailed) |
| `git log --oneline` | View changes (briefly) |
| `git log branchB..branchA` | Show the commits on branchA that are not on branchB |
| `git log --follow [file]` | Show the commits that changed ﬁle, even across renames |
| `git diff [source branch] [target branch]` | Preview changes before merging |
| `git diff branchB...branchA` | Show the diﬀ of what is in branchA that is not in branchB |
| `git show [SHA]` | Show any object in Git in human-readable format|


&nbsp; 

### Tracking Path Changes:

Versioning ﬁle removes and path changes

| Command | Description |
| ------- | ----------- |
| `git rm [file]` | Delete the ﬁle from project and stage the removal for commit.|
| `git mv [existing-path] [new-path]` | Change an existing ﬁle path and stage the move.|
| `git log --stat -M` | Show all commit logs with indication of any paths that moved.|


&nbsp; 

## Rewrite History:

Rewriting branches, updating commits and clearing history

| Command | Description |
| ------- | ----------- |
| `git rebase [branch]` | Apply any commits of current branch ahead of speciﬁed one. |
| `git reset --hard [commit]` | Clear staging area, rewrite working tree from speciﬁed commit.|


&nbsp; 

## Ignoring Patters: 

Preventing unintentional staging or commiting of ﬁles

| Command | Description |
| ------- | ----------- |
| `logs/ *.notes pattern*/` | Save a ﬁle with desired patterns as .gitignore with either direct string matches or wildcard globs. |
| `git config --global core.excludesfile [file]` |  System wide ignore pattern for all local repositories |


&nbsp; 

## Temporary Commits:

Temporarily store modiﬁed, tracked ﬁles in order to change branches

| Command | Description |
| ------- | ----------- |
| `git stash` | Save modiﬁed and staged changes.| 
| `git stash list` | List stack-order of stashed ﬁle changes.|
| `git stash pop` | Write working from top of stash stack.|
| `git stash drop` | Discard the changes from top of stash stack.|



## .git folder

```bash
$ ls -la .git/ 

total 40
drwxr-xr-x  12 aj  staff  384 Nov 29 12:19 .
drwxr-xr-x   4 aj  staff  128 Nov 29 12:04 ..
-rw-r--r--   1 aj  staff   33 Nov 29 12:10 COMMIT_EDITMSG
-rw-r--r--   1 aj  staff   21 Nov 29 12:19 HEAD
-rw-r--r--   1 aj  staff  308 Nov 29 12:19 config
-rw-r--r--   1 aj  staff   73 Nov 29 11:05 description
drwxr-xr-x  15 aj  staff  480 Nov 29 11:05 hooks
-rw-r--r--   1 aj  staff  137 Nov 29 12:10 index
drwxr-xr-x   3 aj  staff   96 Nov 29 11:05 info
drwxr-xr-x   4 aj  staff  128 Nov 29 12:19 logs
drwxr-xr-x  10 aj  staff  320 Nov 29 12:10 objects
drwxr-xr-x   5 aj  staff  160 Nov 29 12:19 refs
```
Layout of Git Repository: https://git-scm.com/docs/gitrepository-layout