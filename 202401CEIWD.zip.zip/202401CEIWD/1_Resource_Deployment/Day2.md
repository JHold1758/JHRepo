# Follow-along for Students:

- You will need a credit card or azure credits to follow along.

# To create an account (pay-as-you-go subscription):
1. https://azure.microsoft.com/en-us/
    
2. Use private email to sign-up and NOT the Divergence email

3. Try Azure free for up to 30 days or pay-as-you-go

# Start Free:
1. https://azure.microsoft.com/en-us/free
2. 12 Free Services, some are always free. List of all free-services: https://azure.microsoft.com/en-us/free#all-free-services

Ensure to never share your subscription_id and other account information.

### Resource Groups Management & Subscriptions:
https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/azure-setup-guide/organize-resources

# Azure Service List:
- https://azure.microsoft.com/en-us/services/

- https://docs.microsoft.com/en-us/azure/?product=all

# Azure CLI Documentation:
https://learn.microsoft.com/en-us/cli/azure/reference-index?view=azure-cli-latest#az-login

# Azure CLI Demo:

## Login to Authenticate with Azure Resource Manager (ARM)

1. `az login`

2. Opens up a browser to login with your personal email credentials for Azure:
https://login.microsoftonline.com/organizations/oauth2/v2.0/authorize?client_id=000000&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A59085&scope=https%3A%2F%2Fmanagement.core.windows.net%2F%2F.default+offline_access+openid+profile&state=FkiWJnVIrQBhXPmL&code_challenge=000000&code_challenge_method=S256&nonce=00000003&client_info=1&claims=%7B%22access_token%22%3A+%7B%22xms_cc%22%3A+%7B%22values%22%3A+%5B%22CP1%22%5D%7D%7D%7D&prompt=select_account

3. After successful login it will load a page with https://localhost:59085/sadjhoefoewijfeowfjew screenshot of the image shared in group-chat
http://localhost:59085/?code=0.000000Vysw-F3NVE10wp8boI9I5ztyoafRd9WmLEtvbBbCbmJh9a64cbN3x2zL7OFoa8vdzQVX6pTpko2JHCdv1GExr_ihh1u6akMgQUqNeqOkKeLZ9oRABVyx4aeJ-TPmL3LLU291g6dsO-fykF_RGaNzxqAtlZlT8mUQ6-qA9Sf5l5FzVwXleQOAZG6PorjmlvdYqlgFZh3eycfXvFoeEMQROPSGreKVgy63QVphzB3p4o3ZnK-rNDLiUJcU2JUcxONKay32gsXQKiDrbepueKEx3bj1phGdKBbaU2s1MJPR4S6zbYdAr42j71CP2E4CqN79fq7g3owHujeQGa3tJy0DG0YyY8zgfeA24YLHXYhT6yqjKs8s7t2QBg4W86uU-BMTP1juqLq8TfUBPCGviqiJaFxjXWQfe4v_lyFi3k1Iiyl4ryRD2b0RIx2rSAFbK3WtZT19LQ34JCTyvUmKcOKR9p0Azc0gdzHQPKwBtvriJ-dgHOU7HU4PQoBT23DnrhYVTzRTD7bOsgRwqmrqT4wnDDPgFwHjgY0yxOM7dBN-P9joMIkqOB4l-eO33QBku1LCb9ceNxoa12yPOiDsYhqY0W-2xiS8PR6pcLThatjFPMGT3RuttIVa0VD2jE8zps7v2pbbDZTpXqfbKBxChi0FensGjDqJ_lOCdNqZ11aRGyjKKp9SGTI330p02p8RDzTjbXIV-SRPh2pA5XY8Y-PUqvDfMXTy4O_gh4DlSY3r4Q1hEcNlHsYBQNNOgL2DeHgz4dmSk038ZAtCNv3apVhzTNgzqZGROB7MtAvHeLYb4eLtEar1ShVsQUR4c3RLRoWQNfqUrtXBW3ILa6D8ybjHM6mGpk-KMeZclf8imNV_7rFzuzHWVhu-q2Ck89qzfR9UA4Pl9QCsfwezb3NUBJ1X0vyAg&client_info=e0000000001dGlkIjoiNGRiYTUyZDktZGQ3YS00NmE1LTk0MjAtNjQ5ZTA1ZjdhZTNlIn0&state=FkiWJnVIrQBhXPmL&session_state=0000000000

4. In the command line it will generate a `JSON` response confirming successful login

```bash
az login
A web browser has been opened at https://login.microsoftonline.com/organizations/oauth2/v2.0/authorize. Please continue the login in the web browser. If no web browser is available or if the web browser fails to open, use device code flow with `az login --use-device-code`.
The following tenants don't contain accessible subscriptions. Use 'az login --allow-no-subscriptions' to have tenant level access.
19a307ce-011a-483d-85e9-acd3d88cd3a8 'JN Training'
[
  {
    "cloudName": "AzureCloud",
    "homeTenantId": "00000000-dd7a-0000-0000-000000000",
    "id": "30000000-a000-00000-0000-0000000000",
    "isDefault": true,
    "managedByTenants": [],
    "name": "Pay-As-You-Go",
    "state": "Enabled",
    "tenantId": "00000000-dd7a-000-0000-00000000",
    "user": {
      "name": "ankit@primecarecorp.com",
      "type": "user"
    }
  }
]
```

##  To check Azure CLI version:

Azure CLI Tools is called `az`

To check the version of our tool: `az --version`

```bash
$ az --version
azure-cli                         2.56.0

core                              2.56.0
telemetry                          1.1.0

Dependencies:
msal                            1.24.0b2
azure-mgmt-resource             23.1.0b2

Python location '/usr/local/Cellar/azure-cli/2.56.0/libexec/bin/python'
Extensions directory '/Users/ankitjariwala/.azure/cliextensions'

Python (Darwin) 3.11.7 (main, Dec  4 2023, 18:10:11) [Clang 15.0.0 (clang-1500.1.0.2.5)]

Legal docs and information: aka.ms/AzureCliLegal


Your CLI is up-to-date.
```

AWS Python SDK equivalent to Azure-CLI is Boto3 Library for Python:
AWS SDK for Python (Boto3): https://aws.amazon.com/sdk-for-python/

# Logout of AZ:
`az logout`

# Azure CLI Setup

## Azure Actions Covered

* Microsoft CLI  setup


## Azure CLI Setup

1. Navigate to [https://learn.microsoft.com/en-us/cli/azure/install-azure-cli](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli/)
2. Follow the link to install the CLI for your operating system
    1. [Windows](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-windows)
    2. [macOS](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-macos)
    3. [Linux (Ubuntu)](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli-linux?pivots=apt) - For other distributions, see the Azure CLI Install home page
3. Download the CLI or follow the instructions for your OS
4. Verify that the installation succeeded by typing `az login` in your terminal.

If you run into any issues, please refer to the Microsoft Azure CLI documentation.

# Azure-CLI > Resource Groups:

* Creating resource groups
* Updating resource groups
* Listing resource groups
* Checking whether a resource group exists
* Deleting resource groups

We will look at how to deal with resource groups via the Azure CLI. Open up your terminal to get started. Make sure to login so that you're authenticated to deal with Azure via the CLI.

## Create Resource Groups via Azure-CLI:

```bash
# Create a Resource Group
az group create -n test-resource-group -l eastus

# Let's update this group to add some relevant tags. We can use `az group update` and verify the tags in Azure Portal Resource Group's Tag Blade
az group update --resource-group test-resource-group --tags "environment=test" "type=general"

# Delete Resource Group
az group delete -n test-resource-group
```

# Use Azure-CLI to create a VM:

### Create a Resource Group:
`az group create -n vm-resource-group -l centralus`

### List Subscriptions:
`az account list`

### Create a vnet to associate with VM:
`az network vnet create -g vm-resource-group -n vm-vnet --subnet-name subnet1 --subnet-prefix 10.0.0.0/24`

```bash
az network vnet create -g vm-resource-group -n vm-vnet --subnet-name subnet1 --subnet-prefix 10.0.0.0/24
{
  "newVNet": {
    "addressSpace": {
      "addressPrefixes": [
        "10.0.0.0/16"
      ]
    },
    "enableDdosProtection": false,
    "etag": "W/\"29eb56f2-b513-4f5d-9b56-83abfaf216af\"",
    "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/virtualNetworks/vm-vnet",
    "location": "centralus",
    "name": "vm-vnet",
    "provisioningState": "Succeeded",
    "resourceGroup": "vm-resource-group",
    "resourceGuid": "45108493-602d-4353-bbb6-f882e9007a88",
    "subnets": [
      {
        "addressPrefix": "10.0.0.0/24",
        "delegations": [],
        "etag": "W/\"29eb56f2-b513-4f5d-9b56-83abfaf216af\"",
        "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/virtualNetworks/vm-vnet/subnets/subnet1",
        "name": "subnet1",
        "privateEndpointNetworkPolicies": "Disabled",
        "privateLinkServiceNetworkPolicies": "Enabled",
        "provisioningState": "Succeeded",
        "resourceGroup": "vm-resource-group",
        "type": "Microsoft.Network/virtualNetworks/subnets"
      }
    ],
    "type": "Microsoft.Network/virtualNetworks",
    "virtualNetworkPeerings": []
  }
```

### Provision a Public-IP address to connect with your VM:
az network public-ip create -g vm-resource-group -n vm-public-ip1

```bash
az network public-ip create -g vm-resource-group -n vm-public-ip1
[Coming breaking change] In the coming release, the default behavior will be changed as follows when sku is Standard and zone is not provided: For zonal regions, you will get a zone-redundant IP indicated by zones:["1","2","3"]; For non-zonal regions, you will get a non zone-redundant IP indicated by zones:null.
{
  "publicIp": {
    "ddosSettings": {
      "protectionMode": "VirtualNetworkInherited"
    },
    "etag": "W/\"b7b8439c-fb11-4c61-9ef2-a1fbb4802d6e\"",
    "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/publicIPAddresses/vm-public-ip1",
    "idleTimeoutInMinutes": 4,
    "ipAddress": "40.122.117.19",
    "ipTags": [],
    "location": "centralus",
    "name": "vm-public-ip1",
    "provisioningState": "Succeeded",
    "publicIPAddressVersion": "IPv4",
    "publicIPAllocationMethod": "Static",
    "resourceGroup": "vm-resource-group",
    "resourceGuid": "7e561c49-e332-468c-aaca-1ab87559aba1",
    "sku": {
      "name": "Standard",
      "tier": "Regional"
    },
    "type": "Microsoft.Network/publicIPAddresses"
  }
}
```
### NIC to attach to VM:
az network nic create -g vm-resource-group --vnet-name vm-vnet --subnet subnet1 -n test-nic1 --public-ip-address vm-public-ip1

```bash
az network nic create -g vm-resource-group --vnet-name vm-vnet --subnet subnet1 -n test-nic1 --public-ip-address vm-public-ip1
{
  "NewNIC": {
    "auxiliaryMode": "None",
    "auxiliarySku": "None",
    "disableTcpStateTracking": false,
    "dnsSettings": {
      "appliedDnsServers": [],
      "dnsServers": [],
      "internalDomainNameSuffix": "socbarjnmbjuho3w5cbosad0ra.gx.internal.cloudapp.net"
    },
    "enableAcceleratedNetworking": false,
    "enableIPForwarding": false,
    "etag": "W/\"a0756015-0962-40b0-ace1-2521ef324f6a\"",
    "hostedWorkloads": [],
    "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/networkInterfaces/test-nic1",
    "ipConfigurations": [
      {
        "etag": "W/\"a0756015-0962-40b0-ace1-2521ef324f6a\"",
        "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/networkInterfaces/test-nic1/ipConfigurations/ipconfig1",
        "name": "ipconfig1",
        "primary": true,
        "privateIPAddress": "10.0.0.4",
        "privateIPAddressVersion": "IPv4",
        "privateIPAllocationMethod": "Dynamic",
        "provisioningState": "Succeeded",
        "publicIPAddress": {
          "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/publicIPAddresses/vm-public-ip1",
          "resourceGroup": "vm-resource-group"
        },
        "resourceGroup": "vm-resource-group",
        "subnet": {
          "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Network/virtualNetworks/vm-vnet/subnets/subnet1",
          "resourceGroup": "vm-resource-group"
        },
        "type": "Microsoft.Network/networkInterfaces/ipConfigurations"
      }
    ],
    "location": "centralus",
    "name": "test-nic1",
    "nicType": "Standard",
    "provisioningState": "Succeeded",
    "resourceGroup": "vm-resource-group",
    "resourceGuid": "a2007578-73a3-4b71-9b1e-062729c3ecb5",
    "tapConfigurations": [],
    "type": "Microsoft.Network/networkInterfaces",
    "vnetEncryptionSupported": false
  }
}
```

### Finally create a VM:

Now that we've provisioned the virtual network, subnet, public IP address, and NIC, now we can use these component-services to create and attach to our new VM

`az vm create -g vm-resource-group -n test-vm1 -l centralus --nics test-nic1 --image Ubuntu2204 --public-ip-sku Standard --admin-username azureuser --admin-password testpassword123!`

```bash
az vm create -g vm-resource-group -n test-vm1 -l centralus --nics test-nic1 --image Ubuntu2204 --public-ip-sku Standard --admin-username azureuser --admin-password testpassword123!
{
  "fqdns": "",
  "id": "/subscriptions/31ca9f3f-a656-45b9-96cc-94bb2b89adf7/resourceGroups/vm-resource-group/providers/Microsoft.Compute/virtualMachines/test-vm1",
  "location": "centralus",
  "macAddress": "00-22-48-49-56-26",
  "powerState": "VM running",
  "privateIpAddress": "10.0.0.4",
  "publicIpAddress": "40.122.117.19",
  "resourceGroup": "vm-resource-group",
  "zones": ""
}
```

#### Delete Resource Group and associated Services:
`az group delete -n vm-resource-group --no-wait`

## Summary of Steps to create a VM:
Individually, on create a vm via azure-cli and share a screenshot of Resource Group showing all the resources created on the discord channel

0. az group create -n vm-resource-group -l centralus

1. az network vnet create -g vm-resource-group -n vm-vnet --subnet-name subnet1 --subnet-prefix 10.0.0.0/24

2. az network public-ip create -g vm-resource-group -n vm-public-ip1

3. az network nic create -g vm-resource-group --vnet-name vm-vnet --subnet subnet1 -n test-nic1 --public-ip-address vm-public-ip1

4. az vm create -g vm-resource-group -n test-vm1 -l centralus --nics test-nic1 --image Ubuntu2204 --public-ip-sku Standard --admin-username azureuser --admin-password testpassword123!

5. az group delete -n vm-resource-group --no-wait


# Example of quick VM:

https://github.com/Azure-Samples/azure-cli-samples/blob/master/virtual-machine/create-vm-quick/create-vm-quick.sh

```bash
# Create a resource group.
az group create --name myResourceGroup --location westeurope

# Create a new virtual machine, this creates SSH keys if not present.
az vm create --resource-group myResourceGroup --name myVM --image Ubuntu2204 --generate-ssh-keys
```

# Connect to Azure VM via SSH:
https://learn.microsoft.com/en-us/azure/virtual-machines/windows/connect-ssh?tabs=azurecli




# Discord Channel:
https://discord.gg/73bKcMmH

# Application Gateway vs Load Balancer