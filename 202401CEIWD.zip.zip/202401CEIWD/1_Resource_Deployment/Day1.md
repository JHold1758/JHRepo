# Student Feedback about last class:
1. Did not have confidence in AZ-104
2. Main Labs were not completed and were marked optional
3. Unable to Create VM or Storage account on their own
4. Just theory and no practical
5. Did not work with Python Virtual Environment, nor Git, nor Jupyter Notebook
6. Python Development Environment Path Variables not set on their local machine


# Plan for the Week of Custom Resource Deployment:
- MarkDown
- TerraForm
- Languages:HCL
- Python (review)
- Jupyter Notebooks
- Python Virtual Environment: venv
- Python (pip) and Mac Package Management (brew)
- Python Environment Variables for Window
- Python Installation on Window
- AZ-104 (review)
- AZ-104 Main Labs
- AZ Portal
- Azure Command-Line (Azure CLI)
- Git & GitHub
- CLI
- Linux CLI
- VS Code
- Modern Technical/DevOps Teams
- Del Day: Job_Ready Folder
- Certification Process
- Capstone: Deploy a VM in Linux with a Static Website.
- Voucher and scheduling the AZ Exam after you are done with the labs


# Mark down Cheatsheets:
https://www.markdownguide.org/cheat-sheet/


### Ordered List:
1. First item
2. Second item
3. Third item

### Table:
| Syntax | Description |
| ----------- | ----------- |
| Header | Title |
| Paragraph | Text |

### Code:
`code`

### Horizontal Rule	
---
### Link
[title](https://www.example.com)


### Image
	![alt text](image.jpg)


# Task 1:

#### Services Comparison:

- Azure for AWS Professionals: https://learn.microsoft.com/en-us/azure/architecture/aws-professional/

- Azure Services Comparisons: https://learn.microsoft.com/en-us/azure/architecture/aws-professional/services

### Create and submit an Azure Architecture Diagram:
You are tasked with designing and submitting a diagram that mirrors the architecture provided - using Azure services.

## Draw.io Diagram

Example/Sample of what you will be submitting:

### Describe the Solution:
#### Service Features
    - Examine the features and functionalities provided by the cloud service.
#### Scalability and Performance
    - Evaluate the service's ability to scale dynamically based on demand and handle peak workloads - think auto-scaling, load balancing, and performance metrics.
#### Reliability and Availability
    - Assess the uptime guarantees, service-level agreements (SLAs), and fault tolerance mechanisms.
#### Security and Compliance
    - Investigate encryption, access controls, authentication mechanisms, and compliance certifications.
#### Data Storage and Management
    - Examine the storage options provided by the service.
#### Integration Capabilities
    - The extent to which the service can seamlessly work with other systems and services.
#### Cost and Pricing Model
    - The pricing structure and associated costs for utilizing the service.
#### Management and Monitoring
    - Evaluate features like integration with dashboards, logging, metrics, alerts, and automation capabilities.
#### Service-Level Agreements (SLAs)
    - Review the SLAs provided by the cloud service for uptime, availability, performance, and support.

Step 2: 
Understand what the application shown in the diagram does.


# Step 1: 30 min

For each Azure Service in the DIAGRAM visit:
- Homepage of Azure Load Balance: https://azure.microsoft.com/en-us/products/load-balancer

- Documentation Page of Azure Load Balance: https://learn.microsoft.com/en-us/azure/load-balancer/load-balancer-overview

![alt text](/assets/diagram1.png)

Create a small description for each of these Services. 











# Main Lab of AZ-104

- 01 Lab Manage Microsoft Entra ID Identities
- 02 Lab Manage Subscriptions and RBAC
- 03 Lab Manage Governance via Azure Policy
- 04 Lab Manage Azure resources by Using the Azure Portal
- 05 Lab Manage Azure resources by Using ARM Templates
- 06 Lab Manage Azure resources by Using Azure PowerShell
- 07 Lab Manage Azure resources by Using Azure CLI
- 08 Lab Implement Virtual Networking
- 09 Lab Implement Intersite Connectivity
- 10 Lab Implement Traffic Management
- 11 Lab Manage Azure Storage
- 12 Lab Manage Virtual Machines
- 13 Lab Implement Web Apps
- 14 Lab Implement Azure Container Instances
- 15 Lab Implement Azure Container Apps
- 16 Lab Backup virtual machines
- 17 Lab Implement Monitoring




[6:13 PM] Corey Harmon (Guest): 01 Lab Manage Microsoft Entra ID Identities
[6:13 PM] Miguel Vivero (Guest): lab 5
[6:13 PM] James Whatley (Guest): lab 3
[6:13 PM] LaTerria Miles (Guest): 01 Lab Manage Microsoft Entra ID Identities
[6:14 PM] Taiwo Sekoni (Guest): 05 Lab Manage Azure resources by Using ARM Templates
[6:14 PM] Roberto Bueno-Delacruz (Guest): Working on lab 2. 
[6:16 PM] gottipolu.gayathri (Guest): Lab 1