### Python OOP:
- Class: contain different methods/functions.  A Class can be public or private.

- Interface:
Interfaces exposes a set of methods/functions of a private class for an outside class to use


Python: Object Oriented Programming
    - Murach's Python Programming 2nd Edition: Section 3 > Page 371
    - https://realpython.com/python3-object-oriented-programming/
    - https://www.datacamp.com/tutorial/python-oop-tutorial
    