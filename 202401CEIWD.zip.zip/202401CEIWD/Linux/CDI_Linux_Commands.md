> hostname

> uname -a

> date




> touch
> cat

Navigation and List:
> ls -lrtha
> ls -lra
> cd ~  
> cd ..
> pwd


Some great Linux Commands you can execute:
> free  
> uptime  
 
  
> curl https://www.exmaple.com/ 
> wget https://www.exmaple.com/downloads/version1   

Run Something as an Admin:
> sudo  {any command as administrator}

To check ICMP Packages to make sure there is an internet connection:
> ping google.com 
> ping 10.4.2.1


You have to keep in mind that different Linux Distros have different commands for updating packages, for exmaple: apt, yum, etc

In Linux you can chain two commands by `&&`