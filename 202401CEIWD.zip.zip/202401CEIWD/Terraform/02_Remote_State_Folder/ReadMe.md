Lost the Folder in sync conflict.

Check if students have taken notes on its contents to populate it again.