# 3django > webapp3

1) Create a new repo: 3django
2) navigate/cd into that repo
3) Spin up pipenv environment (latest version of django)
> pipenv install django
4) Enter the pipenv shell
> pipenv shell

Check Django Version (latest):
> python -c "import django; print(django.get_version())"  
> 5.0.1  

# Create a new `webapp3_project` project:
> django-admin startproject webapp3_project .

# Create a new `pages` app
> python manage.py startapp pages

# Wire up the newly created pages app with the project
> project_level > settings.py

```python
# webapp3_project > settings.py


# Application definition
INSTALLED_APPS = [
    "pages.apps.PagesConfig", # attaching our app with project-level
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]
```
# migrate: to create an initial database based on Django’s default settings

> python manage.py migrate

```bash
python manage.py migrate
Operations to perform:
  Apply all migrations: admin, auth, contenttypes, sessions
Running migrations:
  Applying contenttypes.0001_initial... OK
  Applying auth.0001_initial... OK
  Applying admin.0001_initial... OK
  Applying admin.0002_logentry_remove_auto_add... OK
  Applying admin.0003_logentry_add_action_flag_choices... OK
  Applying contenttypes.0002_remove_content_type_name... OK
  Applying auth.0002_alter_permission_name_max_length... OK
  Applying auth.0003_alter_user_email_max_length... OK
  Applying auth.0004_alter_user_username_opts... OK
  Applying auth.0005_alter_user_last_login_null... OK
  Applying auth.0006_require_contenttypes_0002... OK
  Applying auth.0007_alter_validators_add_error_messages... OK
  Applying auth.0008_alter_user_username_max_length... OK
  Applying auth.0009_alter_user_last_name_max_length... OK
  Applying auth.0010_alter_group_name_max_length... OK
  Applying auth.0011_update_proxy_permissions... OK
  Applying auth.0012_alter_user_first_name_max_length... OK
  Applying sessions.0001_initial... OK
```

Runserver Command:
> python manage.py runserver

```bash
(3django) $  04:47 PM 3django $ python manage.py runserver
Watching for file changes with StatReloader
Performing system checks...

System check identified no issues (0 silenced).
January 30, 2024 - 22:50:22
Django version 5.0.1, using settings 'webapp3_project.settings'
Starting development server at http://127.0.0.1:8000/
Quit the server with CONTROL-C.
```

# Templates:

Template allows individual HTML files can be served by view to a web page specified by the URL.

Almost every web-framework has a Templating Feature to generate HTML files more efficiently.

# `Pattern in Django: Templates > Views > URLs`
`(order of creation does not matter)`

The Views will populate the content to be displayed by Templates HTML. The View will communicate with the model.py and the database to populate the data. The URLs control the initial route, the entry point into a page, such as /about, the views contain the logic or the “what”, and the template has the HTML. For web pages that rely on a database model, it is the view that does much of the work to decide what data is available to the template.

# Create a `templates` folder in the Source Folder

Source Folder is mapped as `BASE_DIR`

> mkdir templates   
> touch templates/home.html  

# Wire up Templates Folder with Base Directory

```python
# webapp3_project/settings.py
from pathlib import Path, os
...
...
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [os.path.join(BASE_DIR, 'templates')],
        # Consolidating all Templates in one folder
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]
```

# HTML Code:
Update templates/home.html

```html
<!-- templates/home.html -->
<h1>Homepage</h1>
<p>Hello, Welcome to my WebPage</p>
```

# pages/view.py

```python
# pages/view.py
from django.views.generic import TemplateView

class HomePageView(TemplateView):
    template_name = 'home.html'

```

# Update the urls.py in project level

```python
# webapp3_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include('pages.urls')), # Project level urls.py tying to App level urls.py
]
```

# Create and Update the urls.py in app level
```python
# pages/urls.py
from django.urls import path
from .views import HomePageView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
    path('', HomePageView.as_view(), name='home')
]
```

# Add an About Page:

> touch templates/about.html

# Update the HTML:

```html
<!-- templates/about.html -->
<h1>About Page</h1>

<h2>Another Page with a new URL</h2>

<p>Welcome to my About Page.</p>
```

# Update pages/views.py

```python
# pages/views.py
from django.views.generic import TemplateView

class HomePageView(TemplateView):
    template_name = 'home.html'

class AboutPageView(TemplateView):
    template_name = 'about.html'
```

# Update pages/urls.py

```python
# pages/urls.py
from django.urls import path
from .views import HomePageView, AboutPageView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('about/', AboutPageView.as_view(), name='about'),
]
```

Runserver Command:
> python manage.py runserver

Navigate to:
> http://127.0.0.1:8000/about/

# Extending Templates

Power of templates is the framework's ability to extend the templates to prevent repetitive tasks for adding header, footer, or navigation pane in each template.

Typically we call it `base` template.

> touch templates/base.html

We will use template-tags to use variables to populate data in the template. 
Django has a minimal templating language for adding links and basic logic in our templates.

Template tags take the form of {% something %} where the “something” is the template tag itself. You can even create your own custom template tags.

https://docs.djangoproject.com/en/5.0/howto/custom-template-tags/

https://docs.djangoproject.com/en/5.0/ref/templates/builtins/

### Create Base Template:
```html
<!-- templates/base.html -->

<header>
    <a href="{% url 'home' %}">Home Page</a> | <a href="{% url 'about' %}">About</a>
    <!-- <a> tag is for creating Hyperlinks in HTML -->
    <!-- "Home Page" will be the Text of the Hyperlink -->
    <!-- Django Tag {% url 'home' %} will provide the location of the Hyperlink -->
</header>

<!-- Block Content Tags can be overwritten by child templates via inheritance -->
{% block content %}
{% endblock content %}
<!-- You can also write {% endblock %} but for readability we use {% endblock content %}  -->
```
### URL Tag:
<a tag is for creating Hyperlinks in HTML
"Home Page" will be the Text of the Hyperlink
Django Tag {% url 'home' %} will provide the location of the Hyperlink

# Block Content Tags
Block Content Tags can be overwritten by child templates via inheritance

Template Inheritance: https://docs.djangoproject.com/en/5.0/ref/templates/language/#template-inheritance

Template inheritance allows you to build a base “skeleton” template that contains all the common elements of your site and defines blocks that child templates can override.

It’s the job of “child” templates to fill the empty blocks with content i.e. things between block and end block tags.

### Update our home.html and about.html to extend the base.html template:

Use {% extends 'base.html' %} to copy html contents of base.html into the respective file so it can be centrally managed in base.html and does not have to be repeated in home.html or about.html

home.html:
```html
<!-- templates/home.html -->
{% extends 'base.html' %}

{% block content %}

<h1>Homepage</h1>
<p>Hello, Welcome to my WebPage</p>

{% endblock content %}
```

about.html:
```html
<!-- templates/about.html -->
{% extends 'base.html' %}

{% block content %}

<h1>About Page</h1>

<h2>Another Page with a new URL</h2>

<p>Welcome to my About Page.</p>

{% endblock content %}
```

# Lab:

Add another URL called "contactus" so we can navigate to: 
http://127.0.0.1:8000/contactus/

`Pattern in Django: Templates > Views > URLs`
`(order of creation does not matter)`

1. created templates/contactus.html
2. updated templates/base.html
3. updated pages/views.py
4. updated pages/urls.py


# Tests in Django:

UnitTest is part of Automated Tests that Developers of Django are responsible for writing for the functionalities they are developing.

`"Code without tests is broken as designed"`

The idea is to automate the process of confiming that the code works as expected. 

Django has robust built-in testing tools for writing and running UnitTests using `django.test import TestCase, SimpleTestCase`

When we created our app folder, django automatically created `tests.py` file for us.

### HTML Status Codes:
https://en.wikipedia.org/wiki/List_of_HTTP_status_codes
Screenshots in General Chat.

HTTP respponse status codes are for the communication between Server and the Client. This is happening at the `Appliction-Layer` of the OSI Model. 

All HTTP response status codes are separated into five classes or categories. The first digit of the status code defines the class of response, while the last two digits do not have any classifying or categorization role. There are five classes defined by the standard:

1xx informational response – the request was received, continuing process
2xx successful – the request was successfully received, understood, and accepted
3xx redirection – further action needs to be taken in order to complete the request
4xx client error – the request contains bad syntax or cannot be fulfilled
5xx server error – the server failed to fulfil an apparently valid request

HTML Status Code: 200 means HTML Page loaded successfully. `the request was successfully received, understood, and accepted`

## Add SimpleTestCase to pages/tests.py for all the pages:
 
```python
# pages/tests.py
from django.test import SimpleTestCase
# SimpleTestCase if we are not using the Database
# Testcase if we are using the Database

class SimpleTests(SimpleTestCase):
    def test_home_page_state_code(self):
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
    
    def test_about_page_status_code(self):
        response = self.client.get('/about/')
        self.assertEqual(response.status_code, 200)
    
    def test_contactus_page_status_code(self):
        response = self.client.get('/contactus/')
        self.assertEqual(response.status_code, 200)
```

## To run our  tests:
> python mange.py test

We’ll do much more with testing in the future, especially once we start working with databases. For now, it’s important to see how easy it is to add tests each and every time we add new functionality to our Django project.

(optional) Further reading PyTest Articles/Tutorials
https://docs.djangoproject.com/en/4.2/topics/testing/overview/

# Create a Public Repo in GitHub for your source code folder `3django` 

So you can deploy your project from this repo.

# Prep Django for Production Deployment:

## Django Default Server vs gunicorn server:

To generate a new Pipfile.lock we run:
> pipenv lock

To add gunicorn server:
- Make a new `Procfile`
- Install gunicorn as our webserver
- Make a on-line change to settings.py file

Create a Procfile in the Source Folder:
> touch Procfile

Procfile
> web: gunicorn webapp3_project.wsgi --log-file -

Install dependencies:
> pipenv install gunicorn==19.9.0

ALLOWED_HOSTS setting represents which host/domain names our Django site can serve.
This is a built-in security feature to prevent HTTP Host Header Attacks, which are possible even under many seemingly-safe web server configurations. The wild card Asterisk * means all domains are acceptable (for our initial deployment) and later we will specify the ip address our our vm (or the hostname).

```python
# webapp3_project/settings.py
...
# '*' means your Django WebApp will server from all IP Addresses
# Usually you specify specific ip address: 10.0.3.4 ->  ALLOWED_HOSTS = ['10.0.3.4']
ALLOWED_HOSTS = ['*']
...
```

Say if we deploy this 3django source folder to an Azure VM with ip address `10.0.3.4` then to access this webserver from your browser type this in address bar:
> 10.0.3.4

Django will not server your browser with an HTML Response unless you specify: ALLOWED_HOSTS = ['10.0.3.4'] in the settings.py

Exit the Virtual Environment:
> exit