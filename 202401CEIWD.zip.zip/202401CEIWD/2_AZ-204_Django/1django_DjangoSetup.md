# AJRepo and Visual Studio Code on Student Machine:
1. Have a dedicated VS Code window mapped to AJRepo Github Repo
2. Have another dedicated VS Code Window dedicated to your personal development environment

# Steps for creating AJRepo:
1. In your Local Computer create a folder called AJRepo
2. Open VSCode and open folder "AJRepo" in your workspace
3. Open a Terminal in VSCode
4. Run Command:
git clone https://github.com/primecarecorp/202401CEIWD.git

# Requirements for Django:

- Git Installed? V-
- VS Code Installed V-
- Python Version V-
- pip Version V-

- Python Virtual Environment Check: What was used in PCEP Course? (conda, virutalenv, pyenv, pipenv, venv) 
Official Virtual Environment venv: https://docs.python.org/3/tutorial/venv.html

Find Windows Python location:
python
>>> import os
>>> import sys
>>> os.path.dirname(sys.executable)

Make sure Python is installed in Windows C Folder otherwise uninstall Python installed in AppData/Local Folder and reinstall python

# Linux:
https://www.lpi.org/our-certifications/lpic-1-overview/ 

# Markdown:
===
- Markdown Tutorial: https://www.markdowntutorial.com/
- Markdown Cheatsheet: https://www.markdownguide.org/cheat-sheet/
- Github Markdown Reference: https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github/basic-writing-and-formatting-syntax
-
# Python Reference:
- https://www.w3schools.com/python/python_dictionaries.asp
- https://www.geeksforgeeks.org/


# Django Tutorials
- Polls App: https://docs.djangoproject.com/en/4.1/intro/tutorial01/
- Library App: https://developer.mozilla.org/en-US/docs/Learn/Server-side/Django/Tutorial_local_library_website

# Django Docs:
- https://docs.djangoproject.com/en/4.2/ or pdf: https://media.readthedocs.org/pdf/django/4.2.x/django.pdf
- https://www.w3schools.com/django/

# Books:
- Django Book (FREE)
- Django 4 by Example (Packt Publishing) (PAID): https://github.com/PacktPublishing/Django-4-by-example


# Django:


### Install Django via PIP:
mac: python -m ensurepip --upgrade
win: py -m ensurepip --upgrade

### Tree command:
brew install tree


### Install Django
pip install django
or
pip3 install django

`pip install Django==5.0.1`

### See list of Pip Packages installed: 
pip list

### Check Django Version:
---
python  
```python 
>> import django  
>> django.VERSION  
>> exit()  
```

---
#### One Line Syntax to check Django version:
  
python -c "import django; print(django.get_version())"

---

pipenv Virtual Envrionment Installation:
===
> pip install pipenv or pip3 install pipenv   
> pipenv --version  
pipenv, version 2023.11.17

For Windows: add C:\Python\Scripts to the Path
https://stackoverflow.com/questions/74254642/how-to-install-pipenv-on-windows

### Use pipenv to spin up an Virtual Environment:

pipenv install django==4.1  
pipenv shell  
exit  

### pipenv when launched creates two files:
- Pipfile
- Pipfile.lock

If there is a `parent` folder with these two files then you cannot create another virtual environment in a `child` folder. Otherwise the two virtual environment will conflict and pipenv will not know which Pipfile and Pipfile.lock to use so it will default to the parent-folder's Pipfile and Pipfile.lock files.

- delete the Pipfile and Pipfile.lock files and you can get rid of the virtual environment

Isolated container containing all the software dependencies for a given python project you are developing. You can lock packages and libraries. So the same developer machine can be used to develop for different python runetime simultaneously. 

Pipenv is similar to `npm` and `yarn` from the Node Ecosystem.

# venv Django using Virtual Environment venv:

First, create the virtual environment:
python3 -m venv django-env

Then, use this environment:

In mac:
source django-env/bin/activate

In cmd.exe
venv\Scripts\activate.bat
In PowerShell
venv\Scripts\Activate.ps1


Next, install django
python -m pip install django

Finally test django is working
django-admin startproject mysite

Deactivate the virtual environment:
deactivate 

If the above deactivation does not work then try:
source deactivate

--- 
# Static vs Dynamic:

Need for a Server is for Dynamic Website.

# Web Framework:
- User Authentication
- Admin Interface
- Templates, routes, views
- Robust Security
- Database Backend (various)
- extend by Packages/Libraries

## Python Webframeworks:
- Django
- Flask (lightweight)
- FastAPI

## Other Programming Languages and their WebFrameworks:
| Languages| Frameworks|
|---|----|
|Java | Spring Boot|
|Ruby | Ruby-on-Rails|
|Go | Gin-Gonic|
|Python | Django|
|JavaScript | Express|
|C#| .Net|
|php|php|


Flask vs Django: 

https://wsvincent.com/flask-vs-django/

---

# Start django project
pipenv install django==4.1  
pipenv shell  
django-admin startproject webapp1_project .  
python manage.py migrate    |  python3 manage.py migrate   
python manage.py runserver  | python3 manage.py runserver  

Browser: http://127.0.0.1:8000  

If no migrate command was ran then it will give you an error like so:
```bash
You have 18 unapplied migration(s). Your project may not work properly until you apply the migrations for app(s): admin, auth, contenttypes, sessions.
Run 'python manage.py migrate' to apply them.
```

# Django Apps:
- A django project can contain multiple apps
- project level vs app level
    - There can be several app level folders but only one project level folder per webapp

`Project-level` means the topmost, parent directory of an application. In this case where both the webapp1_project and pages app folders exist. Once we are inside a specific app we are `app-level`

`django-admin startproject webapp1_project .`  
Adding a period `.` at the end of the command is an optional step that many Django developers do. Without the period Django will ***add an additional directory to the project with the same name as the project***; but with the period it does not.

```bash
python manage.py startapp pages
```
manually add apps to settings of project

It will create an app folder with the specific name you provided in the command and it will create app related files with boilerplate code:
- migrations folder
- __init__.py : 
- admin.py :
- apps.py : 
- models.py : ORM
- tests.py : Unit Tests --> Assertions and in CICD Pipeline it runs in an automated manner. Developers of the code are responsible for writing their respective Unit Test.
- views.py : what is displayed on the browser window

Django automatically installs a new pages directory and several files  in it. But even though the app has been created our hello_project won’t recognize it until we add it to the INSTALLED_APPS config within the hello_project/settings.py file.

Django loads apps from top to bottom, in the INSTALLED_APPS List data-structure, so add new apps below built-in apps because they might depend on apps such as admin, auth, and others.

Note that while it is possible to simply type the name of the app, `pages`, it is better to type the full `pages.apps.PagesConfig` which opens up more flexibility/possibilities in configuring apps (https://docs.djangoproject.com/en/2.2/ref/applications/#configuring-applications)
  
# Django Source Folder Breakdown:

django1 : Source Code Folder
    - webapp_project : project-level folder (Django terminology)
    - app1 : app-level folder (Django terminology)

Docker Containers are created by a `Dockerfile` located at different places in your source-code folder-structure.

`Dockerfile` will be used by Docker-Engine to generate an `image` or `container-image` out of the `source-code` and these images will be used to spin up `containers`.

Azure AppService we can create:
1. WebApp
2. Static WebApp
3. WebApp + Database
4. WordPress on App Service

# AppService WebApp:
In Azure AppService when we create a WebApp:

## Basics:
App Service Web Apps lets you quickly build, deploy, and scale enterprise-grade web, mobile, and API apps running on any platform. Meet rigorous performance, scalability, security and compliance requirements while using a fully managed platform to perform infrastructure maintenance. 

### Project Details:
1. Subscription  
    1.1 Resource Group

### Instance Details:
2. Name: Globally Unique Name (Terraform Random Funtion)
3. Publish:
    - `Code`: Source Code located in a Source Control Repo (GitHub, BitBucket, Azure Repos, etc). Our `django1` folder.
    - `Docker Container`: Azure Container Registry or DockerHub
    - `Static Web App`: upload the html files, images, and videos

4. Runtime Stack: `Python 3.xx` from `Piplock` File
5. Operating System: Linux or Windows
6. Region: "centralus" or "southcentralus"

## Database
## Deployment
## Networking
## Monitoring
## Tags

# PaaS to create WebApp from Source-Code:
- AppService is a PaaS from Azure
- Heroku
- Digital Ocean
- ElasticBeanStalk from AWS
- AppEngine from GCP (Google Cloud Platforms)

# Manage.py
Operating file for Django for any admin or setup related tasks.

In Python you run a .py file by `python NameOfFile.py` or `python3 NameOfFile.py`

Mindful of the location of your command prompt, so run this command frequently:
> pwd  
> ls -lha  

Use autocomplete to ensure you are in the right navigation path.

# SQLLite3 Database:

Python3 ships with a native sqlite3 database, it is an effective for local development but not for production use. It is a RDBMS (Relational Database).

Django creates an instance of this database when we run:

```bash
python manage.py migrate
```

Production Database:
- PostGreSQL (open source and free)
- MariaDB (open source and free)
- Oracle (paid)
- MySQL (paid)

A RDBMS stores structured-data. It stores in hiearchical format:
1. Database
2. Table
3. Columns/Rows

Non-Structured Data: images, videos, and data that has no defined bounds.

Semi-Structured Data: JSON, XML, (partial schema)

Structured Data: rows/columns (schema is defined by columns)

Schema: is a pre-defined structure

# SQL:

If you have a table of customers then an example query:

```sql
select
*
from customers
```

### Exmaple of a Read Query:
```sql
-- specifying column names instead of getting all the columns
select
first_name,
last_name,
addr_line1,
addr_line2 
from customers
where active_flag = 1 -- where clause filters the table data
```

In Databases you can do following operations:
- Create
- Read
- Update
- Delete

CRUD Operations

#### Object Resource Mapping: ORM Software
Class = Table in RDBMS
Class Attributes are Columns
Class Instance are Rows

Django has a native ORM or you can extend Django with 3rd party ORM Libraries/Solutions.

# OOP: Object Oriented Programming

OOP vs Functional

Functional -Lambda Functions

### Python Interpreter:
Interpreted vs Compiled? 

Interpreter: It converts Python Code and Interprets to C Language then C will convert to Machine Byte Code to be run on CPU.

## Python Interactive Shell:

$ python3  

or 

```bash
$ python 
Python 3.10.2 (v3.10.2:a58ebcc701, Jan 13 2022, 14:50:16) [Clang 13.0.0 (clang-1300.0.29.30)] on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> 
>>> print("Hello World!")
>>> exit()
```

# Runserver webaddress breakdown:

Django's local webserver: http://127.0.0.1:8000/

It does not use `httpd` webserver but it has a webserver built-into the Django Package we downloaded using `pip install`

- Loopback address: 127.0.0.0 or 127.0.0.1
- Port Number reserved for Django: 8000

Your Server is running on this loopback address, and your Client (browser) is also located on that same computer where the server is running so the loopback address can be used to access the server.

OSI Layers --> Homework.ipynb

# Port Numbers:

### What is a port?

A port is a virtual point where network connections start and end. Ports are software-based and managed by a computer's operating system. Each port is associated with a specific process or service. Ports allow computers to easily differentiate between different kinds of traffic: emails go to a different port than webpages, for instance, even though both reach a computer over the same Internet connection.

### What is a port number?

Ports are standardized across all network-connected devices, with each port assigned a number. Most ports are reserved for certain protocols — for example, all Hypertext Transfer Protocol (HTTP) messages go to port 80. While IP addresses enable messages to go to and from specific devices, port numbers allow targeting of specific services or applications within those devices.

## Kill a Port in Mac: 
> sudo lsof -t -i tcp:8000 | xargs kill -9

https://www.cloudflare.com/learning/network-layer/what-is-a-computer-port/

### List of Port Numbers:
https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml

# Stop the Webserver:
> control+C

To exit the pipenv Virtual Environment: 
> exit

If you reload http://127.0.0.1:8000 the default-website will not be found.

---





# Add an About page to our website

## Templates
Teamples, Views, and URLs make up a webpage

URL: control initial route, entry point into a page such as /about
View: contains the logic or what to display from the model/database
Template: has HTML with variables

## Django Class-based-Views
function vs class based views

# Django Official Pages:
- Django WebApp: https://docs.djangoproject.com/en/4.2/ref/
- Django API: https://www.django-rest-framework.org

# Day 1 Django Homework:
- Homework: read page 431-433 of Python Cookbook 3rd Edition
- Homework: read first chapter of django book



# Added github link:
https://github.com/primecarecorp/202401CEIWD.git

# Those who want to get ahead: (this Friday or next Monday)
Install Docker Desktop: 
- Windows: https://docs.docker.com/desktop/install/windows-install/
- Mac: https://docs.docker.com/desktop/install/mac-install/
  
Docker Tutorials: https://www.docker.com/play-with-docker/

- Create a DockerHub Account
