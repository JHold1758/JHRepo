Entry-Level Roles: (some cloud certification)

1. DevOps (DevOps Certification)
2. Cloud Engineer (requires Cloud Certifications)
3. Data Analyst (distant third and requires sql)


https://www.linkedin.com/jobs/search?keywords=Entry%20Level%20Devops%20Engineer&location=Dallas%2C%20Texas%2C%20United%20States&geoId=104194190&trk=public_jobs_jobs-search-bar_search-submit&position=1&pageNum=0


# DevOps Engineer (contract)
https://www.linkedin.com/jobs/view/devops-engineer-contract-at-capgemini-3812549366?refId=KE2iuL9YC2nfgA3Nauy5jw%3D%3D&trackingId=5%2FkyTJWnx3BDmV7vLEAD1w%3D%3D&trk=public_jobs_topcard-title 

### Capgemini  Plano, TX
1 week ago   Be among the first 25 applicants (Feb 2 2024 F)

# Job Description

As a DevOps Engineer, you will be doing below tasks:

Implement CI/CD pipelines, monitoring, and auto-scaling for services using Azure services such as Azure DevOps, Jenkins, and Azure Monitor.
Manage databases, virtual machines, dockers, and Azure resources using tools such as Azure CLI, Azure Portal, and Azure PowerShell. Troubleshoot issues related to performance, networking, storage, and security.
Perform initial due-diligence using diagnostic tools to understand the root-cause of the issue and help teams resolve issues
Manage Azure Web Apps, Function Apps, Key Vaults, Azure PostgreSQL
Ensure high availability, backup, and recovery of Azure resources
Work closely with Dev and Infrastructure teams to ensure the products are moving towards the process from development to production smoothly using agile methodologies and best practices.
Automate processes and sub-processes using scripts such as Shell, Python, and PowerShell.
Create/update/maintain scripts for Azure pipelines.
Resolve git related issues such as merge conflicts and code reviews using pull requests and branching strategies.

Show less 
Seniority level
Mid-Senior level
Employment type
Contract
Job function
Engineering and Information Technology
Industries
IT Services and IT Consulting