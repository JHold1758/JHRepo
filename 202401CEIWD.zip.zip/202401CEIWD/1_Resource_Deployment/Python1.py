# Regular Python Commands
print('Hello World')