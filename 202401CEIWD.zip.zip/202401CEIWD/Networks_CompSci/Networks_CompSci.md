Vox YouTube: How does the Internet Work? https://www.youtube.com/watch?v=TNQsmPf24go

Screenshots shared in General Chat on OSI Layers.