Describe your Capstone Project:

Deploying Virtual Machine with Infrastructure as a Code Tool called Terraform. Here are the resources being deployed:
- VNET
- Bastian Host
- 
- 