# Blog App: CSS Static Files + CRUD Operations + User Authentication

A Blog has a title, author, and body. 

Make sure you exit out of the earlier Python Environment:
> exit 

Make a new folder:
> mkdir 5django

Navigate to the folder:
> cd 5django

### Create a Project and an App:
> pipenv install django==4.1  
> pipenv shell  
> django-admin startproject blog_project .    
> python manage.py startapp blog    
> python manage.py migrate    
> python manage.py runserver    

http://127.0.0.1:8000/  
control+c  

Wire up your app with project-level: 
- blog_project/settings.py

```python
# blog_project/settings.py
INSTALLED_APPS = [
    "blog.apps.BlogConfig",
```
---
### Setup admin
python manage.py createsuperuser   
Username:  
Email:  
Password:  
python manage.py runserver  
http://127.0.0.1:8000/admin  
Login with the created admin profile  

---
### Connect DBeaver
Copy Path of the `db.sqllite3 `file  
Add a new connection (make sure to test the connection)  
Notice the `auth_user` table rows  

---

# Database Models:
A Blog has a title, author, and body. 

blog/models.py
```python
# blog/models.py
from django.db import models

# Our table will be called "appname_modelname"
class Post(models.Model): # A Blog has a title, author, and body. 
    
    # Title Column -> CharField()
    title = models.CharField(max_length=200) 
    # this will be our column in our table `Post`

    # Author will be the user that logs-in and creates/modifies the Blog
    author = models.ForeignKey(
        'auth.User',
        on_delete=models.CASCADE, 
        # When the user is deleted in auth_user table all the blogs in the 
        # Post table assocaited with this author wil also be deleted.
    )

    # Body Column -> TextField()
    body = models.TextField()


    def __str__(self):
        return self.title[:75]
    # this will display 75 character of the text field in the 
    # Admin UI, you can store more characters in the database 
    # but in the Admin UI only the first 75 will show up.
```

### Register our new model with blog/admin.py

```python
# blog/admin.py
from django.contrib import admin

from .models import Post

# Register your models here.
admin.site.register(Post)

# this will make the Post Model show up in the admin page
```

Create migration file in blog folder:
> python manage.py makemigrations blog

Generate SQL Statements for ORM so WebAPP can communicate with Database:
> python manage.py migrate blog

```bash
(5django) 5django $ python manage.py makemigrations blog
Migrations for 'blog':
  blog/migrations/0001_initial.py
    - Create model Post


(5django) 5django $ python manage.py migrate blog
Operations to perform:
  Apply all migrations: blog
Running migrations:
  Applying blog.0001_initial... OK
```

> python manage.py runserver  

Add few Blog Posts and notice the Username dropdown.

Check in Dbeaver > blog_post table the new entries by the admin ui. Notice the the author_id column (foreign key) and the auth_user "id".

# Create UI to Generate the Blog Post instead of using Admin UI:

## ReactJS vs Django UI
Normally, we will use ReactJS for creating UI/Webpage but Django is one of the few Webframeworks that has UI Features for building a webpage using Templates and its Tagging Library with Database calling with its built-in ORM (object-resource mapping) library.

But in modern applications, the backends are typically APIs (REST, GraphQL, RPC, etc) and ReactJS has an ability to asynchronously call multiple-apis and produce a unified webpage. A webpage in react is broken down into multiple components and each component will fetch its own data from its respective API calls.

If we were to build our big application using only Django then our UI/webpage will be limited to Django Tagging Library and if we needed to make an outside-API (outside resources similar to subscribing to a SaaS) calls then we will have to modify our Django application. And this will make our Django application a big Monolith. So to move away from Monolithic Architecture and use multilple Webframeworks & APIs we evolve our webapp to be composed of several microservices and our webapp UI/frontend will be composed of ReactJS which can consume several-microservices to produce a unified webpage for our users.

`UI Pattern: Templates > View > URLs`

> touch blog/urls.py

```python
# blog/urls.py
from django.urls import path

from .views import BlogListView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
    path('', BlogListView.as_view(), name='home'),
]
```

Wire up our app-level urls.py with project-level urls.py:
```python
# blog_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', include('blog.urls')), # point it to app-level urls.py
]
```

Create a View to populate data from database so that we can pass it to the templates/home.html:
```python
# blog/views.py
from django.views.generic import ListView
from .models import Post

# Create your views here to populate data from database
# This is where the ORM of Django interacts with the database

class BlogListView(ListView):
    model = Post
    template_name = 'home.html'

```

Create the Teamplates where we can use the data from View and use the Template Tagging Library to build our UI:

Create a `templates` folder in BASE_DIR or Source Folder:
> mkdir templates
> touch templates/base.html
> touch templates/home.html

Wire-up our `templates` folder with our blog_project/settings.py:
```python
# blog_project/settings.py
import os
from pathlib import Path
...
...
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [os.path.join(BASE_DIR, 'templates')], ########
...
```

Update my templates/base.html:
```html
<!-- templates/base.html -->
<html>
    <head>
        <h1>Django Blogs:</h1>
    </head>
    <body>
        <header>
            <a href="{% url 'home' %}"></a>
        </header>
        <div>
            {% block content %}
            {% endblock content %}
        </div>
    </body>
</html>
```

The View has populated the data from the database in a object_list, we will use this to create our UI in templates/home.html:
```html
<!-- templates/home.html -->
{% extends 'base.html' %}

{% block content %}
<!-- Everything in between the block content will be put inside the block content tags of base.html -->
    {% for post in object_list %}
        <div class="post_entry">
            <h2><a href="">{{ post.title }}</a></h2>
            <p>{{ post.body }}</p>
        </div>
    {% endfor %}

{% endblock content %}
```

> python manage.py runserver

Now you can see the Blog Post in the homepage. Now you can see the Database Data being reflected in the Browser/UI. But do not have the ability to update or add to the Database from the Browser/UI.

Milestone!!!! We have connected our Database with our Admin App and UI


---

# Static_Files in Django:

Examples of static assets:
- css
- images (branding, icons,)

# Static Files vs. Cookies:
Cookies are different than Static Files. 
- Cookies will store User/Client data:
    - Session Data
    - Targeting Data
    - Frequently delete your cookies and session data
    - Horrible Popup Buzzkill Popup: 
        - Necessary Cookies, 
        - Accept All Cookies,
        - Customize:

Exmaple: https://stackoverflow.com/questions/3469705/how-to-run-script-commands-from-variables 

### Strictly Necessary Cookies: Always Active
These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.

### Performance Cookies:
These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.


###  Targeting Cookies:
These cookies are used to make advertising messages more relevant to you and may be set through our site by us or by our advertising partners. They may be used to build a profile of your interests and show you relevant advertising on our site or on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device.


###  Functional Cookies
These cookies enable the website to provide enhanced functionality and personalisation. They may be set by us or by third party providers whose services we have added to our pages. If you do not allow these cookies then some or all of these services may not function properly.


## Static Folder in Blog App for CSS:

HTML & CSS resources: https://www.w3schools.com/html/html_css.asp 

Project-Level Folder called `static`:
> (5django) $  09:22 AM 5django $ mkdir static  

When you created a project-level folder called `templates` what do you remember doing in Django? 

Update settings.py with a one-line change for `STATICFILES_DIRS` variable by adding the `STATIC_URL`

Let Django know of this static folder in: `blog_project/settings.py`
> blog_project/settings.py > STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]

```python
# blog_project/settings.py
import os
from pathlib import Path
...
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [os.path.join(BASE_DIR, 'templates')], ########
        "APP_DIRS": True,
...
# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/4.1/howto/static-files/

STATIC_URL = "static/"
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]
...
```

Create folder structure within our new `static` folder to store base.css:
> mkdir static/css
> touch static/css/base.css

Add css code to static/css/base.css
- Make header tag `h1`: red

```html
<!-- templates/base.html -->
<html>
    <head>
        <h1>Django Blogs:</h1>
    </head>
    <body>
```

```css
/* static/css/base.css */

h1 {
    color: crimson;
}
```

Extend `static/css/base.css` css file using `{% load static %}` tags to `base.html` and add a `link` tag to the `head` tag <link href="{% static 'css/base.css' %}" rel="stylesheet">

`{% load static %}` tag will load `static/css/base.css`

```html
<!-- templates/base.html -->
{% load static %}
<html>
    <head>
        <link href="{% static 'css/base.css' %}" rel="stylesheet">
        <h1>Django Blogs:</h1>
    </head>
```

Add Custom Font in the `head` tag. We will use `Source Sans 3` a free font from Google.
https://fonts.google.com/specimen/Source+Sans+3 

`Source Sans Pro` is depricated so we will use `Source Sans 3`
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400" rel="stylesheet">

Add the Font CDN/Mirror to base.html: 

```html
<!-- templates/base.html -->
{% load static %}
<html>
    <head>
        <link href="{% static 'css/base.css' %}" rel="stylesheet">
        <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400" rel="stylesheet"> -->
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3&display=swap" rel="stylesheet">
        <h1>Django Blogs:</h1>
    </head>
```

Now we will use this font that we have imported from the header tag link tag:

```css
/* static/css/base.css */

body {
    font-family: 'Source Sans 3', sans-serif;
    font-size: 18px;
}

header {
    border-bottom: 1px solid #999;
    margin-bottom: 2rem;
    display: flex;
}

h1 {
    color: crimson;
    text-decoration: none;
}

.nav-left {
    margin-right: auto
}

.nav-right {
    display: flex;
    padding-top: 2rem;
}

/* <div class="post-entry"> */
.post-entry {
    margin-bottom: 2rem;
}

/* <h2><a href="">{{ post.title }}</a></h2> */
.post-entry h2 {
    margin: 0.5rem 0;
}

.post-entry h2 a,
.post-entry h2 a:visited {
    color: blue;
    text-decoration: none;
}

/* <p>{{ post.body }}</p> */

.post-entry p {
    margin: 0;
    font-weight: 400;
}

.post-entry h2 a:hover {
    color: red;
}
```

Add more css code to base.css

---

# Create a new UI to load all the Blog Details: 
Click on the blog title and load all the columns of that row in a Detailed View.

As of now the href is pointing to blank page

```html
<!-- templates/home.html -->
<div class="post-entry">

<!-- Make this Title Clickable -->
<!-- as of now the href is pointing to blank page so it does nothing -->
<!-- but we want to navigate to a new webpage that lists all columns of blog_post -->
<h2><a href="">{{ post.title }}</a></h2> 
```
We are going to load this new `BlogDetailView` based on the `id` passed from our `click action` of that particular blog entry and the Django WebApp will make a Database Call to load the respective `row` associated to that `id`.

***UI Pattern: Templates > View > URLs***

Q: What loads the data from the database?

A: View populates data from database so that we can pass it to the templates/home.html

ListView/DetailView: https://docs.djangoproject.com/en/5.0/ref/class-based-views/generic-display/

Django will create the SQL Queries to load all the columns of the table for a particular row (instance of the `Post` model class).

blog/views.py > import DetailView and create a BlogDetailView Class and point it to template: post_detail.html. The BlogDetailView creates a context object with all the columns which the template will access via the tags `{{ post.body }}`.

```python
# blog/views.py
from django.views.generic import ListView, DetailView
from .models import Post

# Create your views here to populate data from database
# This is where the ORM of Django interacts with the database

class BlogListView(ListView):
    model = Post
    template_name = 'home.html'

# We are using Django's views.generic API by importing DetailView Class
# Then we are makeing this DetailView Class our own with BlogDetailView
class BlogDetailView(DetailView):
    model = Post
    template_name = 'post_detail.html'
```

Now we have Django populate the data via this blog/view.py and next we will use this data to build our UI.

Create the template file we are referring to in our view's `BlogDetailView` Class:
> touch templates/post_detail.html

In post_detail.html add:
- extends base.html
- specify database table's column names to be displayed in this view

```html
<!-- templates/post_detail.html -->
<!-- blog/view.py > BlogDetailView will load templates/post_detail.html -->
<!-- BlogDetailView is pulling Post model -->
{% extends 'base.html' %}

<!-- The view BlowDetailView will provide me all the columns 
for the specific row the user clicks on 

We display the title and body from our context object which 
the BlogDetailView makes accessible as post-->
{% block content %}
<div class="post-entry">
    <h2>{{ post.title }}</h2>
    <h3>{{ post.id }}</h3>
    <p>{{ post.body }}</p>
</div>

{% endblock content %}
```

The last piece of our UI Pattern is URLs: blog/urls.py

Create URL to access this Post Detail View: http://127.0.0.1:8000/post/1/
    - import BlogDetailView
    - path('post/<int:pk>/',BlogDetailView.as_view(), name='post_detail'),


All blog post entries will start with path `post/` 

Our primary key for our post entry will be represtented as an integer <int:pk> 

Django automatically adds an auto-incrementing primary key to our database models. So while we only declared the fields title, author, and body on our Post model, under-the-hood Django also added another field called id, which is our primary key. We can access it as either id or pk.

> python manage.py runserver

> visit > http://127.0.0.1:8000/post/1/

Next, we will link the title of the blogs in the homepage with the BlogDetailView/blog_detail.html using `a` tag and django-tag `url` 

Use the primary key to create a url link to each of the post's BlogDetailView in templates/home.html:
```html 
<h2><a href="{% url 'post_detail' post.pk %}">{{ post.title }}</a></h2>
```

|Change from|Change to|
|----|----|
|`<h2><a href="">{{ post.title }}</a></h2>`|`<h2><a href="{% url 'post_detail' post.pk %}">{{ post.title }}</a></h2>`|

templates/home.html
```html
<!-- templates/home.html -->
{% extends 'base.html' %}

{% block content %}
<!-- Everything in between the block content will be put inside the block content tags of base.html -->
    {% for post in object_list %}
        <div class="post-entry">
            <!-- Routing: use Django's Tagging Library to create a URL to by transferring from BlogListView's templates/home.html to each blog's BlogDetailView tempalates/blog_detail.html -->
            <h2><a href="{% url 'post_detail' post.pk %}">{{ post.title }}</a></h2>
            <p>{{ post.body }}</p>
        </div>
    {% endfor %}

{% endblock content %}
```

> python manage.py runserver

> visit > http://127.0.0.1:8000/ Click on a Blog Entry and Notice the URL Change

Milestone!!!! First routing from one url to another

# Add Test Cases in blog/test.py
What are we going to test:
- model: Post
- view: ListView and BlogDetailView
- template
- url (status code 200 ok)

```python
# blog/tests.py 
from django.contrib.auth import get_user_model 
from django.test import Client, TestCase 
from django.urls import reverse

from .models import Post

class BlogTests(TestCase):

    def setUp(self):
        self.user = get_user_model().objects.create_user( 
            username='testuser', 
            email='test@email.com', 
            password='secret' 
        )

        self.post = Post.objects.create(
            title='A good title',
            body='Nice body content', 
            author=self.user,
        )

    def test_string_representation(self):
        post = Post(title='A sample title')
        self.assertEqual(str(post), post.title)

    def test_post_content(self):
        self.assertEqual(f'{self.post.title}', 'A good title') 
        self.assertEqual(f'{self.post.author}', 'testuser') 
        self.assertEqual(f'{self.post.body}', 'Nice body content')

    def test_post_list_view(self):
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200) 
        self.assertContains(response, 'Nice body content')
        self.assertTemplateUsed(response, 'home.html')

    def test_post_detail_view(self):
        response = self.client.get('/post/1/')
        no_response = self.client.get('/post/10000/')
        self.assertEqual(response.status_code, 200) 
        self.assertEqual(no_response.status_code, 404) 
        self.assertContains(response, 'A good title') 
        self.assertTemplateUsed(response, 'post_detail.html')
```

> python manage.py test

Next we will add/edit the Blog Posts from UI/Webpage instead of Admin UI.

# Forms in Django:
Forms: a user can create, edit, or delete any of their blog entries

`The first rule of web application security is never to trust user input`

Whenever we accept a user input there are security concerns, such as:
- Cross site scripting (XSS) protection
- Cross site request forgery (CSRF) protection
- SQL injection protection
- Clickjacking protection
- SSL/HTTPS
- Host header validation
- Referrer policy
- Cross-origin opener policy
- Session security
- User-uploaded content

Proper error handling is required and there are UI Considerations around how to alert the user to the problems with the form. If no errors, then user is redirected on success to the intended target url.

Django's built-in `Forms` abstracts away much of the complexities and difficulties, while provides a rich set of tools to handle common use cases.

Django Security: https://docs.djangoproject.com/en/4.2/topics/security/

CRUD Operation:
C: Create  
R: Read  
U: Update  
D: Delete  

### Static vs Dynamic: (continued)
Static Website has no state whereas a Dynamic Website has a state and it is stored in the Database.

Example: A Website where users can provide their email to sign-up to your Newsletter or submit a Contact-Form to request a call-back or a return-email (download ebook).


Django Forms allows secure CRUD. Next we will add /post/new/ URL to add new post from our Homepage.

# C: Create of CRUD
# Create a new Blog Post via a "New Blog Post" Link/Button:

When the user click on the  "New Blog Post" Button/Link on the Homepage this URL: http://127.0.0.1:8000/post/new/ will load.

1) Create a tag in base.html to provide a link to "New Post":
    - <a href="{% url 'post_new' %}">+ New Blog Post</a>
2) Created a template for this new link: 
    - touch templates/post_new.html
3) Updated the templates/post_new.html
    - html form tag with post method to create the new blog post and add to our database
    - `{% csrf_token %}` : `XSS` protection or cross site scripting attack protection
    when you open it in html inspect you will see:
    `<input type="hidden" name="csrfmiddlewaretoken" value="LExdRbI3w9ryozMbkiFaw9KfBEgUSRtI0vrXlmioJZr1Gi2EPA7eyIKKcueMORYa">`
    - {{ form.as_p }} : output our table columns and map it to html input fields
    - html input tag: Save Button/Link for Post Action
4) Design and Create a new path when creating a new post in blog/urls.py:
    - path('post/new/',BlogCreateView.as_view(), name='post_new'),
5) Create the mentioned view class "BlogCreateView" in blog/view.py
6) What action to perform after clicking the Save Button in New Blog Post? 
    - Create a get_absolute_url function in Post Class of blog/model.py
    - this will load the post_detail.html of the new blog post we just created

`UI Pattern: Templates > View > URLs`

> touch templates/post_new.html

Updated the templates/post_new.html
```html
<!-- templates/post_new.html -->
{% extends 'base.html' %}

{% block content %}
    <h1>New Post</h1>

<!-- User is inputting data and sending it to our WebApp and then to our Database -->
    <form action="" method="post"> 

<!-- XSS protection or cross site scripting attack protection to protect our form from crosssite scripting attacks. 
You should use it for all your Django forms. 
When you open {% csrf_token %} token in html inspect you will see:
<input type="hidden" name="csrfmiddlewaretoken" value="LExdRbI3w9ryozMbkiFaw9KfBEgUSRtI0vrXlmioJZr1Gi2EPA7eyIKKcueMORYa"> -->
        {% csrf_token %}

<!-- {{ form.as_p }}: to output our table columns and map it to html input fields in p tags  -->
        {{ form.as_p }}

        <input type="submit" value="Save" />

    </form>
{% endblock content %}
```

```python
# blog/urls.py
from django.urls import path

from .views import BlogListView, BlogDetailView, BlogCreatelView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
    path('', BlogListView.as_view(), name='home'),
    path('post/<int:pk>/', BlogDetailView.as_view(), name='post_detail'),
    path('post/new/', BlogCreatelView.as_view(), name='post_new'),
]
```

```python
# blog/views.py
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView #
from .models import Post
....
....
class BlogCreatelView(CreateView):
    model = Post
    template_name = 'post_new.html'
    fields = '__all__' # we only have two: title and author
```
> python manage.py runserver

Notice the error message when we click Save on our new Blog Post. It is complaining that we didnot specify where to send the user after successfully submitting the form. 

What action to perform after clicking the Save Button in New Blog Post? 
    - Create a `get_absolute_url()` function in Post Class of blog/model.py
    - this will load the post_detail.html of the new blog post we just created

Let's send the user to the BlogDetailedView and it's associated template post_detail.html so the user can see their completed/submitted Blog Post.

We can do this by adding a `get_absolute_url()` function to our model. It sents a cononical URL for an object so even if the sucture of our URLS changes in the furture, the reference to the specific object is the same. As a best practice, we should always add a `get_absolute_url()` and `__str__()` functions to every model we create.

```python
# blog/models.py
from django.db import models
from django.urls import reverse #

# Our table will be called "appname_modelname"
class Post(models.Model): # A Blog has a title, author, and body. 
    
    # Title Column -> CharField()
    title = models.CharField(max_length=200) 
    # this will be our column in our table `Post`
...
...
...

    def get_absolute_url(self):
# Reverse is a very handy utility function Django provides us to reference 
# an object by its URL template name, in this case post_detail.
        return reverse('post_detail', args=[str(self.id)])
# path('post/<int:pk>/', BlogDetailView.as_view(), name='post_detail'),
# pk and id are interchangeable
# redirects to URL path: posts/pk or posts/id
```

> python manage.py runserver

Now when you refresh that error page with id=3 it will confirm whether to resubmit. And when you do the post_detail page will load with id=4. You can check in the DBeaver for the duplicate entry with id=3. 

While html "post" method is loading, you might have seen a warning message when submitting a reservation where the warning says "Please do not reload this page" otherwise it will duplicate your reservation. Typically, with one `html post method` several calls would go out to serveral microservices and these microservices can take different time to process their request so you see the long loading sign.


## Official Dango Explanation: Cross site scripting (XSS) protection

XSS attacks allow a user to inject client side scripts into the browsers of other users. This is usually achieved by storing the malicious scripts in the database where it will be retrieved and displayed to other users, or by getting users to click a link which will cause the attacker’s JavaScript to be executed by the user’s browser. However, XSS attacks can originate from any untrusted source of data, such as cookies or web services, whenever the data is not sufficiently sanitized before including in a page.

Using Django templates protects you against the majority of XSS attacks. However, it is important to understand what protections it provides and its limitations.

Django templates escape specific characters which are particularly dangerous to HTML. While this protects users from most malicious input, it is not entirely foolproof. For example, it will not protect the following:

`<style class={{ var }}>...</style>`

If `var` is set to `class1 onmouseover=javascript:func()`, this can result in unauthorized JavaScript execution, depending on how the browser renders imperfect HTML. (Quoting the attribute value would fix this case.)

It is also important to be particularly careful when using `is_safe` with custom template tags, the `safe` template tag, `mark_safe`, and when autoescape is turned off.

In addition, if you are using the template system to output something other than HTML, there may be entirely separate characters and words which require escaping.

You should also be very careful when storing HTML in the database, especially when that HTML is retrieved and displayed.

---

### XSS (cross site scripting attack): AJ's explation
https://docs.djangoproject.com/en/4.2/topics/security/
https://www.stackhawk.com/blog/django-xss-examples-prevention/
   
When you open `{% csrf_token %}` in html-inspect (Browser's Developer Tools) you will see:  
`<input type="hidden" name="csrfmiddlewaretoken" value="LExdRbI3w9ryozMbkiFaw9KfBEgUSRtI0vrXlmioJZr1Gi2EPA7eyIKKcueMORYa">`

XSS is a `vulnerability in web applications that allows the execution of illegitimate client-side scripts`. And from an attacker’s perspective, an XSS attack is a technique where the attacker injects malicious client-side scripts into the web application's response to the browser. When the user requests the affected page, the malicious script is executed. Malicious actors use XSS for various purposes, including these common occurrences:

- Stealing of sensitive information
- Identity theft
- Remote code execution

For example, let’s say that a web application takes a username as input and then greets the user using their name. If the input to a field in the web application is `Tony`, then the response sent to the user would be:  

`Hello, Tony!`

Mechanics: the application is using the input and adding a pre-decided text. Once the application builds this result, it sends this result as a response to the user’s browser (where this maliscious response is rendered).  

The above example might seem harmless. But let’s see how this process could be dangerous. `The first rule of web application security is never to trust user input`. So, what if instead of giving the username as input, a bad actor gave a malicious input? If the input was `<script>alert(‘XSS’);</script>`;, the response sent to user would be:  
`Hello, <script>alert(‘XSS’);</script>`

And this code, when rendered, would display an alert with the text “XSS”. But this injection wouldn’t work in Django, because `Django has an automatic HTML escaping feature to counter XSS`. This `HTML Escaping` feature converts certain HTML-characters into their respective HTML-code as follows:  

- `< is converted to <`
- `> is converted to >`
- `‘ (single quote) is converted to ' `
- `“ (double quote) is converted to "`
- `& is converted to &`

So, when the above malicious input is given, Django converts the input to `<script>alert(‘XSS‘);</script>`. And when this output is rendered in the browser, nothing is  executed because it is not a script anymore.  

---

Next we will implement the Update, and Delete

---

Have a great weekend.

### HW over the weekend: 
- (optional) checkout Django tutorials https://docs.djangoproject.com/en/4.2/

- Those who attended the Fair: to review notes from students who were part of the class. Make sure to run all the docker commands.


---
# Notes about Learning Django:

- Try your code, fail with error messages and make sure to READ the error-messages. 
- READ READ READ your error messages

1. Django Official Documentation: 
2. Google Search (not Big Search)
3. Search Stack Overflow (only use it as a reference but always match it up with the official Django Documentation)

---

## U: Update of CRUD > Update existing Blog Post:
http://127.0.0.1:8000/post/1/edit/

We do not need another View (webpage) to put our update link, we can provide a button in the "post_detail.html"

`UI Pattern: Templates > View > URLs`

1) Add an `Edit Blog Post` link to `post_detail.html`
    - `<a href="{% url 'post_edit' post.pk %}">+ Edit Blog Post</a>`
2) Create the `post_edit.html` template that we used in the link tag above:
    - touch templates/post_edit.html
3) Add HTML Code to our `post_edit.html`
    - html form tag with post method to update the specific blog post in our database
    - {% csrf_token %} : XSS protection or cross site scripting attack protection
    - {{ form.as_p }} : output our table columns and map it to html input fields
    - html input tag: Update Button/Link for Post Action
4) Design and Create a new path when updating a particular post in `blog/urls.py`:
    - `path('post/<int:pk>/edit/', BlogUpdateView.as_view(), name='post_edit'),`
5) Create the mentioned view class `BlogUpdateView` using buil-in `UpdateView` object in blog/views.py and add:
    - model called Post to populate the data
    - point it to our new tamplate `post_edit.html`
    - use all the columns from the table
6) What action to perform after clicking the Update Button? As done previously in `Create` component of the CRUD, in `Update` as we we will use the same `get_absolute_url()` function of the `Post` Class in `blog/model.py`. On successful update, that same function will load our `post_detail.html` of the blog post we just updated `return reverse('post_detail', args=[str(self.id)])`. So nothing to change in the code.

> python manage.py runserver    

Step 1: Add an "Update" link to templates/post_detail.html
```html
<!-- templates/post_detail.html -->
<!-- blog/view.py > BlogDetailView will load templates/post_detail.html -->
<!-- BlogDetailView is pulling Post model -->
{% extends 'base.html' %}

<!-- The view BlowDetailView will provide me all the columns 
for the specific row the user clicks on 

We display the title and body from our context object which 
the BlogDetailView makes accessible as post-->
{% block content %}
<div class="post-entry">
    <h2>{{ post.title }}</h2>
    <h3>{{ post.id }}</h3>
    <p>{{ post.body }}</p>
    <!-- Users can click on this link to edit the post: -->
    <a href="{% url 'post_edit' post.pk %}">+ Edit Blog Post</a>
</div>

{% endblock content %}
```

Step 3: Add html code to templates/post_edit.html
```html
<!-- templates/post_edit.html -->
{% extends 'base.html' %}


{% block content %}
<h1>Edit Post:</h1>

    <form action="" method="post"> 
        <!-- XSS protection or cross site scripting attack protection to protect our form from crosssite scripting attacks. 
        You should use it for all your Django forms. 
        When you open {% csrf_token %} token in html inspect you will see:
        <input type="hidden" name="csrfmiddlewaretoken" value="LExdRbI3w9ryozMbkiFaw9KfBEgUSRtI0vrXlmioJZr1Gi2EPA7eyIKKcueMORYa"> -->
                {% csrf_token %}
        <!-- {{ form.as_p }}: to output our table columns and map it to html input fields in p tags  -->
                {{ form.as_p }}
                <input type="submit" value="Update" />
        </form>

{% endblock content %}
```
Step 4: Add URL Path:
```python
# blog/urls.py
from django.urls import path

from .views import BlogListView, BlogDetailView, BlogCreatelView, BlogUpdateView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
    path('', BlogListView.as_view(), name='home'),
    path('post/<int:pk>/', BlogDetailView.as_view(), name='post_detail'), 
    # pk and id are interchangeable
    path('post/new/', BlogCreatelView.as_view(), name='post_new'),
    path('post/<int:pk>/edit/', BlogUpdateView.as_view(), name='post_edit'),
]
```

Step 5: Add the View mentioned in URL Path
```python
# blog/views.py
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView  #
from .models import Post
# We are importing from the Django API the UpdateView class/object to later
# make our own Class out of it called BlogUpdateView

# Create your views here to populate data from database
# This is where the ORM of Django interacts with the database
class BlogListView(ListView):
    model = Post
    template_name = 'home.html'

# We are using Django's views.generic API by importing DetailView Class
# Then we are makeing this DetailView Class our own with BlogDetailView
class BlogDetailView(DetailView):
    model = Post
    template_name = 'post_detail.html'


class BlogCreatelView(CreateView):
    model = Post
    template_name = 'post_new.html'
    fields = '__all__' # we only have two: title and author

class BlogUpdateView(UpdateView):
    model = Post
    template_name = 'post_edit.html'
    fields = ['title','body']
```
> python manage.py runserver 

## D: Delete of CRUD > Delete existing Blog Post:
http://127.0.0.1:8000/post/1/delete/

`UI Pattern: Templates > View > URLs`

1) Add an `Delete Blog Post` link to `post_detail.html`
    - `<a href="{% url 'post_delete' post.pk %}">+ Delete Blog Post</a>`
2) Create the `post_delete.html` template that we used in the link tag above:
    - touch templates/post_delete.html
3) Add html code to our `post_delete.html`
    - html `form` tag with `post method` to delete the particular blog post from our database
    - {% csrf_token %} : XSS protection or cross site scripting attack protection
    - Alert the User of Delete Action with the specific post: `<p>Are you sure you want to delete "{{ post.title }}" ?</p>`
    - html input tag: Confirm Button/Link for Delete Action
4) Design and Create a new path when deleting that particular post in `blog/urls.py`:
    - `path('post/<int:pk>/delete/', BlogDeleteView.as_view(), name='post_delete'),`
5) Create the mentioned view class "BlogDeleteView" using buil-in "DeleteView" object in `blog/views.py`
    - `success_url = reverse_lazy('home')` # It won't execute the URL redirect to home.html until our view has finished deleting the specific blog post
6) What action to perform after clicking the Confirm Delete Button? The `reverese_lazy('home')` in the blog/views.py after succesful delete will load the home.html

We use reverse_lazy as opposed to just reverse so that it won’t execute  the URL redirect until our view has finished deleting the blog post. Whereas just the resverse will immediately redirect without waiting for the delete action.

> python manage.py runserver    

Step 1: Add an `Delete Blog Post` link to `post_detail.html`
```html
<!-- templates/post_detail.html -->
{% extends 'base.html' %}

{% block content %}
<div class="post-entry">
    <h2>{{ post.title }}</h2>
    <p>{{ post.body }}</p>
</div>

<p><a href="{% url 'post_edit' post.pk %}">+ Edit Blog Post</a></p>
<p><a href="{% url 'post_delete' post.pk %}">+ Delete Blog Post</a></p>

{% endblock content %}
```

Step 3: Add html code to our `post_delete.html`
```html
<!-- templates/post_delete.html -->
{% extends 'base.html' %}

{% block content %}
    <h1>DELETE Blog Post:</h1>
    <form action="" method="post">
        {% csrf_token %}
        
        <p>Are you sure you want to delete "{{ post.title }}" ?</p>
        <p>{{ post.body }}</p>
        <input type="submit" value="Confirm" />
    </form>
    
{% endblock content %}
```

Step 4: Design and Create a new path when deleting that particular post in `blog/urls.py`:
```python
# blog/urls.py
from django.urls import path

from .views import BlogListView, BlogDetailView, BlogCreatelView, BlogUpdateView, BlogDeleteView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
    path('', BlogListView.as_view(), name='home'),
    path('post/<int:pk>/', BlogDetailView.as_view(), name='post_detail'), 
    # pk and id are interchangeable
    path('post/new/', BlogCreatelView.as_view(), name='post_new'),
    path('post/<int:pk>/edit/', BlogUpdateView.as_view(), name='post_edit'),
    path('post/<int:pk>/delete/', BlogDeleteView.as_view(), name='post_delete'),
]
```

Step 5: Create the mentioned view class "BlogDeleteView" using buil-in "DeleteView" object in `blog/views.py`
```python
# blog/views.py
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
# We use reverse_lazy as opposed to just reverse so that it won’t execute 
# the URL redirect until our view has finished deleting the blog post.
# whereas just the resverse will immediately redirect without waiting for 
# the delete action.

from .models import Post
# We are importing from the Django API the UpdateView class/object to later
# make our own Class out of it called BlogUpdateView

# Create your views here to populate data from database
# This is where the ORM of Django interacts with the database
class BlogListView(ListView):
    model = Post
    template_name = 'home.html'

# We are using Django's views.generic API by importing DetailView Class
# Then we are makeing this DetailView Class our own with BlogDetailView
class BlogDetailView(DetailView):
    model = Post
    template_name = 'post_detail.html'


class BlogCreatelView(CreateView):
    model = Post
    template_name = 'post_new.html'
    fields = '__all__' # we only have two: title and author

class BlogUpdateView(UpdateView):
    model = Post
    template_name = 'post_edit.html'
    fields = ['title','body']

class BlogDeleteView(DeleteView):
    model = Post
    template_name = 'post_delete.html'
    success_url = reverse_lazy('home') 
# It won't execute the URL redirect until our view has finished deleting 
# the blog post. In the Create/Update the model.py has the get_absolute_url() 
# function (with reverse-lazy to redirect to post_detail.html but when 
# we are deleting the post we cannot load the post_detail view 
```
> python manage.py runserver 

---

# User Authentication for our Blog App:

User Accounts to implement Authentication (User Registration and Login), and Authorization (permission) is a core feature of any dynamic website. Static Websites do not have any Server to interact with so there is no user-accounts and basically anyone can access your static-website. 

We will implement log-in, log-out, and sign-up functionality. Django provides us with the necessary views and urls out-of-the-box with `auth` app for log-in and log-out functionalities and we only have to update a template to make it work. Buut sign-up will require more setup.

User authentication in Django: https://docs.djangoproject.com/en/5.0/topics/auth/

Remember the table `auth_user` in Dbeaver? So there is a built-in app called `auth` that any Django PRoject starts with (when we run the `django-admin startproject project-name .`)

Whenever we want to create a new Database Table we create a new Django App within your Project.

Whenever we created the project, Django had installed the `auth` app which provides us an `User` Object with following colums: (verify in DBeaver)

- username
- password
- email
- first_name
- last_name

We will use this `User` Object to `implement log-in, log-out, and sign-up functionality` to our blog app.

In project-level urls.py file `blog_project/urls.py` create a path `account/` and associate it with the built-in `auth` app (Django's built in user authentication system): 
- `path('accounts/', include('django.contrib.auth.urls'))`

```python
# blog_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', include('blog.urls')), # point it to app-level urls.py
    path('accounts/', include('django.contrib.auth.urls')), 
    # Attach the built-in Django User Authentication System
    # We do not have to create another app folder for it in our source folder/BASE_DIR
    # User authentication in Django: https://docs.djangoproject.com/en/5.0/topics/auth/
]
```

Usually we point it to an app's urls.py file but we did not have to create a new User/Authentication App, we are going to use the built-in `Django-Auth` functionality which provides us with basic authentication and user-management.

## Login: 

http://127.0.0.1:8000/accounts/login/

The built-in `Django-Auth` functionality will look within our `templates` folder for another folder called  `registration` and inside it expects a `login.html`:
- > mkdir templates/registration
- > touch templates/registration/login.html

Add HTML to templates/registration/login.html Template:
- html form tag use post method
- {% csrf_token %} : XSS protection or cross site scripting attack protection
- {{ form.as_p }} : output our AUTH table columns and map it to html input fields
- html button tag: Login Button/Link for Login Post Action

`auth_user` table:
- id
- password
- last_login
- is_super_user
- username
- last_name
- email
- is_staff
- is_active
- date_join
- first_name

```html
{% extends 'base.html' %}

{% block content %}
<h1>Log In:</h1>

    <form action="" method="post"> 
        <!-- XSS protection or cross site scripting attack protection to protect our form from crosssite scripting attacks. 
        You should use it for all your Django forms. 
        When you open {% csrf_token %} token in html inspect you will see:
        <input type="hidden" name="csrfmiddlewaretoken" value="LExdRbI3w9ryozMbkiFaw9KfBEgUSRtI0vrXlmioJZr1Gi2EPA7eyIKKcueMORYa"> -->
                {% csrf_token %}
        <!-- {{ form.as_p }}: to output our table columns and map it to html input fields in p tags  -->
                {{ form.as_p }}
                <input type="submit" value="Login" />
        </form>

{% endblock content %}
```

We need to specifiy where to redirect the user upon successful login:
- `blog_project/settings.py` at the bottom > `LOGIN_REDIRECT_URL = 'home'`

```python
# blog_project/settings.py
...
...
...
# Successful Login Redirection to home page where 'home' is the name
# we have given in blog/urls.py to home.html
LOGIN_REDIRECT_URL = 'home'
```
> python manage.py runserver    

http://127.0.0.1:8000/accounts/login/

```html
<!-- templates/registration/login.html -->
{% extends 'base.html' %}

{% block content %}
<h1>Log In:</h1>

    <form action="" method="post"> 
        <!-- XSS protection or cross site scripting attack protection to protect our form from crosssite scripting attacks. 
        You should use it for all your Django forms. 
        When you open {% csrf_token %} token in html inspect you will see:
        <input type="hidden" name="csrfmiddlewaretoken" value="LExdRbI3w9ryozMbkiFaw9KfBEgUSRtI0vrXlmioJZr1Gi2EPA7eyIKKcueMORYa"> -->
                {% csrf_token %}
        <!-- {{ form.as_p }}: to output our table columns and map it to html input fields in p tags  -->
                {{ form.as_p }}
                <input type="submit" value="Login" />
        </form>

{% endblock content %}
```

## Show login-status of the User in our Homepage:

Edit `templates/base.html`:
- Use if/else statement with `is_authenticated` attribute flag to do a check
- Use the `user` table and `username` field

`{% if user.is_authenticated %}
    <p><u> Hello! {{ user.username }}</u></p>
{% else %}
    <p>You are not Logged-In.</p>
    <a href="{% url 'login' %}">Login-In</a>
{% endif %}`

```html
<!-- templates/base.html -->
{% load static %}
<html>
    <head>
        <link href="{% static 'css/base.css' %}" rel="stylesheet">
        <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400" rel="stylesheet"> -->
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3&display=swap" rel="stylesheet">
        <h1>Django Blogs:</h1>
    </head>
    <body>
        <header>
            <a href="{% url 'home' %}">Home</a>  &nbsp; &nbsp; | &nbsp; &nbsp;  <a href="{% url 'post_new' %}">+ New Blog Post</a> 
        </header>
            <!-- user object is what the built-in auth app provides -->
            {% if user.is_authenticated %} 
                <p><u> Hello! {{ user.username }}</u></p>
            {% else %}
                <p>You are not Logged-In.</p>
                <a href="{% url 'login' %}">Login-In</a>
            {% endif %}
        <div>
            {% block content %}
            {% endblock content %}
        </div>
    </body>
</html>
```

# Logout Link:
Edit `templates/base.html`:
- Add logout link in the if statement: <p><a href="{% url 'logout' %}">Logout</a>
- No View and no template needs to be created for logout action, use the built-in logout functionality of the `auth` app

```html
{% if user.is_authenticated %}
    <h3>Hello! {{ user.username }}</h3>
    <p><a href="{% url 'logout' %}">Logout</a>
{% else %}
    <p>You are not Logged-In.</p>
    <a href="{% url 'login' %}">Login-In</a>
{% endif %}
```

We need to specifiy where to redirect the user upon successful logout in `blog_project/settings.py` add the following line as a new line all the way at the bottom:
> `LOGOUT_REDIRECT_URL = 'home'`

```python
# blog_project/settings.py
...
...
...
# Successful Login Redirection to home page where 'home' is the name
# we have given in blog/urls.py to home.html
LOGIN_REDIRECT_URL = 'home'
LOGOUT_REDIRECT_URL = 'home'
```

```html
<!-- templates/base.html -->
{% load static %}
<html>
    <head>
        <link href="{% static 'css/base.css' %}" rel="stylesheet">
        <!-- <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400" rel="stylesheet"> -->
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Source+Sans+3&display=swap" rel="stylesheet">
        <h1>Django Blogs:</h1>
    </head>
    <body>
        <header>
            <a href="{% url 'home' %}">Home</a>  &nbsp; &nbsp; | &nbsp; &nbsp;  <a href="{% url 'post_new' %}">+ New Blog Post</a> 
        </header>
        <!-- user object is what the built-in auth app provides -->
        <!-- Check if User is Authenticated -->
            {% if user.is_authenticated %} 
                <p><u> Hello! {{ user.username }}</u></p> &nbsp; &nbsp; | &nbsp; &nbsp; <p><a href="{% url 'logout' %}">Logout</a>
                
            {% else %}
                <p>You are not Logged-In.</p>
                <a href="{% url 'login' %}">Login-In</a>
            {% endif %}
        <div>
            {% block content %}
            {% endblock content %}
        </div>
    </body>
</html>
```
> python manage.py runserver    


# Signup Process: 
http://127.0.0.1:8000/accounts/signup/

We need to write our own view for a sign-up page to register new users, we will use the `UserCreationForm` from Django's API which comes with three fields: `username`, `password1`, and `password2`

Create a new `accounts` app within our source folder. Then by updating the models.py in it, we can create a new table in the DB but instead we will use the built-in `auth_user` table to add our users into:
- > python manage.py startapp accounts

Link our new `accounts` app in `blog_project/settings.py` > INSTALLED_APPS List:
- `"accounts.apps.AccountsConfig", # Signup Process in accounts_app`
```python
# blog_project/settings.py
# Application definition
INSTALLED_APPS = [
    "blog.apps.BlogConfig", # Adding the new app in project-level
    "accounts.apps.AccountsConfig", # Signup Process in accounts_app
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    'whitenoise.runserver_nostatic', #whitenoise
    "django.contrib.staticfiles",
]
```

Connect our Project with our App: Provide path in blog_project/urls.py to connect to the app's urls.py:
- path('accounts/', include('accounts.urls')),

```python
# blog_project/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path('', include('blog.urls')), # point it to app-level urls.py
    path('accounts/', include('django.contrib.auth.urls')), # Login Page
    # Attach the built-in Django User Authentication System
    # We do not have to create another app folder for it in our source folder/BASE_DIR
    # User authentication in Django: https://docs.djangoproject.com/en/5.0/topics/auth/
    path('accounts/', include('accounts.urls')), # Signup page
]
```
Reminder!
`UI Pattern: Template > View > URL`

create a app level `urls.py` in the accounts folder:
- > touch accounts/urls.py

In the `account/urls.py` > Add a route to a new signup template:
- `path('signup/', SignUpView.as_view(), name='signup'),`

```python
# accounts/urls.py
from django.urls import path

from .views import SignUpView
# By using the period .views we reference the current directory, which is our pages app containing both views.py and urls.py

urlpatterns = [
   path('signup/', SignUpView.as_view(), name='singup'),
]
```

View: account/views.py add `UserCreationForm`:
- Use UserCreationForm: adds the new user in `auth_user` database
- success_url: What to do when signup successful, and redirect only when succesfully written in database
- template_name: singup.html

```python
# accounts/views.py
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic

class SignUpView(generic.CreateView): 
# We are subclassing the generic class-based view  "CreateView" in our 
# SignUpView Class
    form_class = UserCreationForm
    success_url = reverse_lazy('login') # Upon Successful Registration
    template_name = 'signup.html' # The view will populate data for this template
```

Create signup.html template
- > touch templates/signup.html

Add HTML to our signup.html
    - html form tag with post method to update the user table in our database
    - {% csrf_token %} : XSS protection or cross site scripting attack protection
    - {{ form.as_p }} : output our table columns and map it to html input fields
    - html button tag: Signup Button/Link for Post Action

```html
<!-- templates/signup.html -->
{% extends 'base.html' %}

{% block content %}
    <h1>Signup Page:</h1>
    <form method="post">
        {% csrf_token %}
        
        {{ form.as_p }}
        <button type="submit">Sign-up</button>
    </form>
    
{% endblock content %}
```
> python manage.py runserver    

http://127.0.0.1:8000/accounts/signup/

---

# Practise: 

1. pull the above code of Blog App
2. Create a new Book-Library App: adding new books with title author, add user authentication
3. For your Signup validation Checks you 3rd party Django Libraries: django-crispy-forms
4. Add Bootstrap: https://getbootstrap.com/docs/5.0/getting-started/introduction/ 

# To make your website bootstrapped, use the Start Template Above. Here is the summary:

1. Required Meta Tags in head tag:
`<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">`

2. Bootstrap CSS in head tag:
`<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">`

3. In the Body Tag: 
`<!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>`


## Bootstrap Starter template:

Be sure to have your pages set up with the latest design and development standards. That means using an HTML5 doctype and including a viewport meta tag for proper responsive behaviors. Put it all together and your pages should look like this:

```html

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body>
    <h1>Hello, world!</h1>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
  </body>
</html>

```

##  Quick start with Bootstrap

Looking to quickly add Bootstrap to your project? Use jsDelivr, a free open source CDN. Using a package manager or need to download the source files? Head to the downloads page.
### CSS

Copy-paste the stylesheet <link> into your <head> before all other stylesheets to load our CSS.

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

### JS

Many of our components require the use of JavaScript to function. Specifically, they require our own JavaScript plugins and Popper. Place one of the following <script>s near the end of your pages, right before the closing </body> tag, to enable them.
Bundle

Include every Bootstrap JavaScript plugin and dependency with one of our two bundles. Both bootstrap.bundle.js and bootstrap.bundle.min.js include Popper for our tooltips and popovers. For more information about what’s included in Bootstrap, please see our contents section.

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

### Separate

If you decide to go with the separate scripts solution, Popper must come first (if you’re using tooltips or popovers), and then our JavaScript plugins.

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity

## Navigation Bar Component of Bootstrap:
https://getbootstrap.com/docs/5.0/components/navbar/

# One of AJ's Project code you can use as a sample:

- Replace the links with newer bootstrap links
- Slaying the Dragon YouTube Tutorials (Thank you Lance!)

```html
<!-- templates/base.html --> <!doctype html>

<html lang="en">

<head> <!-- Required meta tags -->

<meta charset="utf-Ǘ">

<meta name="viewport" content="width=device-width,

initial-scale=ǐ, shrink-to-fit=no">

<!-- Bootstrap CSS -->

<link rel="stylesheet"

href="https://stackpath.bootstrapcdn.com/bootstrap/Ǔ.ǐ.ǒ/css/\ bootstrap.min.css" integrity="shaǒǗǓ-MCwǘǗ/SFnGEǗfJTǒGXwEOngsVǖZtǑǖNXFoaoApmYmǗǐi\ uXoPkFOJwJǗERdknLPMO"

crossorigin="anonymous">

<title>Django Blogs:</title>
</head> <body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark mb-Ǔ">

<a class="navbar-brand" href="{% url 'home' %}">Home</a>
<button class="navbar-toggler" type="button" data-toggle="collapse"

data-target="#navbarCollapse" aria-controls="navbarCollapse"

aria-expanded="false" aria-label="Toggle navigation">

<span class="navbar-toggler-icon"></span>

</button>

<div class="collapse navbar-collapse" id="navbarCollapse">

{% if user.is_authenticated %}

<ul class="navbar-nav ml-auto">

<li class="nav-item">

<a class="nav-link dropdown-toggle" href="#" id="userMenu"

data-toggle="dropdown" aria-haspopup="true"

aria-expanded="false">

{{ user.username }} </a>

<div class="dropdown-menu dropdown-menu-right"

aria-labelledby="userMenu">

<a class="dropdown-item"

href="{% url 'password_change'%}">Change password</a>

<div class="dropdown-divider"></div>

<a class="dropdown-item" href="{% url 'logout' %}">

Log Out</a> </div> </li> </ul> {% else %}

<form class="form-inline ml-auto">

<a href="{% url 'login' %}" class="btn btn-outline-secondary"> Log In </a>
<a href="{% url 'signup' %}" class="btn btn-primary ml-2">
    Sign up</a> </form> {% endif %} </div> </nav>

<div class="container">

{% block content %} {% endblock content %} </div>

<!-- Optional JavaScript --> <!-- jQuery first, then Popper.js, then Bootstrap JS --> <script src="https://code.jquery.com/jquery-ǒ.ǒ.ǐ.slim.min.js" integrity="shaǒǗǓ-qǗi/X+ǘǕǔDzOǏrTǖabKǓǐJStQIAqVgRVzpbzoǔsmXKpǓ\ YfRvH+ǗabtTEǐPiǕjizo"

crossorigin="anonymous"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/\ ǐ.ǐǓ.ǒ/ umd/popper.min.js" integrity="shaǒǗǓ-ZMPǖrVoǒmIykV+Ǒ+ǘJǒUJǓǕjBkǏWLaUAdnǕǗǘaCwoqbB\ JiSnjAK/ lǗWvCWPIPmǓǘ"

crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/Ǔ.ǐ.ǒ/\ js/bootstrap.min.js" integrity="shaǒǗǓ-ChfqqxuZUCnJSKǒ+MXmPNIyEǕZbWhǑIMqEǑǓǐrYiqJxyMiZ\ ǕOW/JmZQǔstwEULTy"

crossorigin="anonymous"></script>

</body>
</html>
```